from django.apps import AppConfig


class BaseFileConfig(AppConfig):
    name = 'base_file'
