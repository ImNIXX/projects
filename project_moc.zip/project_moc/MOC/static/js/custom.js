$(document).ready(function () {
  $("#nav-toggle").click(function () {
    if ($(window).width() >= 1200) {
      if ($("#nav-toggle").text() == 'Collapse') {
        $("#nav-container").css("width", "7%");
        $("#nav-container").css("transition", "0.5s");
        $('.main-content-nav').css("width", "0%");
        $(".main-content-nav-list-icons").toggle();
        $("ul.main-content-nav-list li .main-content-nav-list-anchor-text").toggle();
        $("#nav-toggle").text(">");

        $("#main-container").css("width", "87%");
        $("#main-container").css("transition", "0.5s");
      }
      else {
        $("#nav-container").css("width", "18%");
        $("#nav-container").css("transition", "0.5s");
        $('.main-content-nav').css("width", "100%");
        $(".main-content-nav-list-icons").toggle();
        $("ul.main-content-nav-list li .main-content-nav-list-anchor-text").toggle();
        $("#nav-toggle").text("Collapse");

        $("#main-container").css("width", "76%");
        $("#main-container").css("transition", "0.5s");
      }
    }
    else {
      if ($("#nav-toggle").text() == 'Collapse') {
        $("#nav-container").css("width", "9%");
        $("#nav-container").css("transition", "0.5s");
        $(".main-content-nav-list-icons").toggle();
        $("ul.main-content-nav-list li .main-content-nav-list-anchor-text").toggle();
        $("#nav-toggle").text(">");

        $("#main-container").css("width", "87%");
        $("#main-container").css("transition", "0.5s");
      }
      else {
        $("#nav-container").css("width", "0%");
        $("#nav-container").css("transition", "0.5s");
        $(".main-content-nav-list-icons").toggle();
        $("ul.main-content-nav-list li .main-content-nav-list-anchor-text").toggle();
        $("#nav-toggle").text("Collapse");

        $("#main-container").css("width", "76%");
        $("#main-container").css("transition", "0.5s");
      }
    }
  });
});

$('body').on('click', '.safe-tab-btn', function () {
  var class_name = $(this).data('name');
  $('.common_tab').addClass('dis_none');
  $('.' + class_name).removeClass('dis_none');
})

$("#sectionForm").submit(function (event) {

  event.preventDefault();
  var title_changes = $('#title_changes').val();
  var name_email = $('#name_email').val();
  var date_changes = $('#date_changes').val();
  var Proposal_changes = $('#Proposal_changes').val();
  var business_case = $('#business_case').val();
  var Datestart = $('#Datestart').val();
  var Dateend = $('#Dateend').val();
  var implications = $('#implications').val();
  var Estimate = $('#Estimate').val();
  var anyBoxesChecked = false;
  $('input[name="type_of_change"]').each(function () {
    if ($(this).is(":checked")) {
      anyBoxesChecked = true;
    }
  });
  var BoxesChecked = false;
  $('input[name="chngeduration"]').each(function () {
    if ($(this).is(":checked")) {
      BoxesChecked = true;
    }
  });

  if (title_changes == "" || name_email == "" || date_changes == "" || anyBoxesChecked == false || BoxesChecked == false || Proposal_changes == "" || business_case == "" || Datestart == "" || Dateend == "" || implications == "" || Estimate == "") {
    if (title_changes == "") { $('#title_changes').addClass('error_class'); }
    if (name_email == "") { $('#name_email').addClass('error_class'); }
    if (date_changes == "") { $('#date_changes').addClass('error_class'); }
    if (anyBoxesChecked == false) { $('.type_of_change').css("box-shadow", "1px 1px red"); }
    if (BoxesChecked == false) { $('.chngeduration').css("box-shadow", "1px 1px red"); }
    if (Proposal_changes == "") { $('#Proposal_changes').addClass('error_class'); }
    if (business_case == "") { $('#business_case').addClass('error_class'); }
    if (Datestart == "") { $('#Datestart').addClass('error_class'); }
    if (Dateend == "") { $('#Dateend').addClass('error_class'); }
    if (implications == "") { $('#implications').addClass('error_class'); }
    if (Estimate == "") { $('#Estimate').addClass('error_class'); }
    $('html, body').animate({
      scrollTop: $('#title_changes').offset().top
    }, 800, function () { });
  } else {
    $('#sectionForm').unbind('submit').submit();

  }
});
// datepicker previous date deactivate except current date



// $( "#sectionForm" ).submit(function( event ) {
//     event.preventDefault();
//     //type of changes delect box
//     var anyBoxesChecked = false;           
//     $('input[name="type_of_change"]').each(function(){
//       if ($(this).is(":checked")) {      
//         anyBoxesChecked = true; 
//       }             
//     });

//     //temprory-permanent checkbox
//     var BoxesChecked = false;           
//     $('input[name="chngeduration"]').each(function(){
//       if ($(this).is(":checked")) {      
//         BoxesChecked = true; 
//       }             
//     });

//     var title_changes = $('#title_changes').val();
//     var name_email = $('#name_email').val();
//     var date_changes=$('#date_changes').val();
//     var Proposal_changes=$('#Proposal_changes').val();
//     var business_case=$('#business_case').val();
//     var Datestart=$('#Datestart').val();
//     var Dateend=$('#Dateend').val();
//     var implications=$('#implications').val();
//     var Estimate=$('#Estimate').val();



//     if (title_changes == ""){
//       //$('#title_changes_valid').html('**This is Required Field.')
//       $('#title_changes').addClass('error_class');
//       $('html, body').animate({
//         scrollTop: $('#title_changes').offset().top
//       }, 800, function(){

//         // Add hash (#) to URL when done scrolling (default click behavior)
//         window.location.title_changes = title_changes;
//       });
//     }  
//     else if(name_email == ""){

//       //$("#name_email_valid").html('**This is Required Field.');
//       $('#name_email').addClass('error_class');
//       $('html, body').animate({
//         scrollTop: $('#name_email').offset().top
//       }, 800, function(){

//         // Add hash (#) to URL when done scrolling (default click behavior)
//         window.location.title_changes = title_changes;
//       });
//     }else if(date_changes == ""){
//       //$("#date_changes_valid").html('**This is Required Field.')
//       $('#date_changes').addClass('error_class');
//       $('html, body').animate({
//         scrollTop: $('#date_changes').offset().top
//       }, 800, function(){

//         // Add hash (#) to URL when done scrolling (default click behavior)
//         window.location.title_changes = title_changes;
//       });
//     }  
//      else if (anyBoxesChecked == false) {
//      // $('#type_of_change_valid').html('**chose one option');
//      $('.type_of_change').css("box-shadow","1px 1px red");
//      $('html, body').animate({
//       scrollTop: $('.type_of_change').offset().top
//     }, 800, function(){

//       // Add hash (#) to URL when done scrolling (default click behavior)
//       window.location.title_changes = title_changes;
//     });
//      return false;

//     }else if(BoxesChecked == false){
//       //$("#chngeduration_valid").html('**chose one option')
//       $('.chngeduration').css("box-shadow","1px 1px red");
//       $('html, body').animate({
//         scrollTop: $('.chngeduration').offset().top
//       }, 800, function(){

//         // Add hash (#) to URL when done scrolling (default click behavior)
//         window.location.title_changes = title_changes;
//       });
//     }else if(Proposal_changes == ""){
//       //$("#Proposal_changes_valid").html('**This is Required Field.')
//       $('#Proposal_changes').addClass('error_class');
//       $('html, body').animate({
//         scrollTop: $('#Proposal_changes').offset().top
//       }, 800, function(){

//         // Add hash (#) to URL when done scrolling (default click behavior)
//         window.location.title_changes = title_changes;
//       });
//     }else if(business_case == ""){
//       //$("#business_case_valid").html('**This is Required Field.')
//       $('#business_case').addClass('error_class');
//       $('html, body').animate({
//         scrollTop: $('#business_case').offset().top
//       }, 800, function(){

//         // Add hash (#) to URL when done scrolling (default click behavior)
//         window.location.title_changes = title_changes;
//       });
//     }else if(Datestart == ""){
//       //$("#Datestart_valid").html('**This is Required Field.')
//       $('#Datestart').addClass('error_class');
//       $('html, body').animate({
//         scrollTop: $('#Datestart').offset().top
//       }, 800, function(){

//         // Add hash (#) to URL when done scrolling (default click behavior)
//         window.location.title_changes = title_changes;
//       });
//     }else if(Dateend == ""){
//       //$("#Dateend_valid").html('**This is Required Field.')
//       $('#Dateend').addClass('error_class');
//       $('html, body').animate({
//         scrollTop: $('#Dateend').offset().top
//       }, 800, function(){

//         // Add hash (#) to URL when done scrolling (default click behavior)
//         window.location.title_changes = title_changes;
//       });
//     }else if(implications == ""){
//      // $("#implications_valid").html('**This is Required Field.')
//      $('#implications').addClass('error_class');
//      $('html, body').animate({
//       scrollTop: $('#implications').offset().top
//     }, 800, function(){

//       // Add hash (#) to URL when done scrolling (default click behavior)
//       window.location.title_changes = title_changes;
//     });
//     }else if(Estimate == ""){
//       //$("#Estimate_valid").html('**This is Required Field.')
//       $('#Estimate').addClass('error_class');
//       $('html, body').animate({
//         scrollTop: $('#Estimate').offset().top
//       }, 800, function(){

//         // Add hash (#) to URL when done scrolling (default click behavior)
//         window.location.title_changes = title_changes;
//       });
//     }else{

//       //Form submit code
//       $('#sectionForm').unbind('submit').submit();
//       //event.submit();
//     }
//   });



//Remove Validation if key press
$("#title_changes").keyup(function (event) {
  // $('#title_changes_valid').html('')
  $("#title_changes").removeClass('error_class');
});
$("#name_email").keyup(function (event) {
  // $('#name_email_valid').html('')
  $('#name_email').removeClass('error_class');
});
$("#date_changes").change(function (event) {
  // $('#date_changes_valid').html('')
  $('#date_changes').removeClass('error_class');
});
$(".type_of_change").click(function (event) {
  // $('#type_of_change_valid').html('')
  $('.type_of_change').css("box-shadow", "");
});
$(".chngeduration").click(function (event) {
  // $('#chngeduration_valid').html('')
  $(".chngeduration").css("box-shadow", "");
});
$("#Proposal_changes").keyup(function (event) {
  // $('#Proposal_changes_valid').html('')
  $('#Proposal_changes').removeClass('error_class');
});
$("#business_case").keyup(function (event) {
  // $('#business_case_valid').html('')
  $('#business_case').removeClass('error_class');
});
$("#Datestart").change(function (event) {
  // $('#Datestart_valid').html('')
  $('#Datestart').removeClass('error_class');
});
$("#Dateend").change(function (event) {
  //$('#Dateend_valid').html('')
  $('#Dateend').removeClass('error_class');
});
$("#implications").keyup(function (event) {
  // $('#implications_valid').html('')
  $('#implications').removeClass('error_class');
});
$("#Estimate").keyup(function (event) {
  // $('#Estimate_valid').html('')
  $('#Estimate').removeClass('error_class');
});

(function ($) {
  "use strict";

  $(function () {
    var header = $(".start-style");
    $(window).scroll(function () {
      var scroll = $(window).scrollTop();

      if (scroll >= 10) {
        header.removeClass('start-style').addClass("scroll-on");
      } else {
        header.removeClass("scroll-on").addClass('start-style');
      }
    });
  });

  //Animation

  $(document).ready(function () {
    $('body.hero-anime').removeClass('hero-anime');
  });

  //Menu On Hover

  $('body').on('mouseenter mouseleave', '.nav-item', function (e) {
    if ($(window).width() > 750) {
      var _d = $(e.target).closest('.nav-item'); _d.addClass('show');
      setTimeout(function () {
        _d[_d.is(':hover') ? 'addClass' : 'removeClass']('show');
      }, 1);
    }
  });


})(jQuery);


//signup

$('#sign_up_form').validate({
  rules: {
    name: {
      required: true,
    },
    username: {
      required: true,
    },
    email: {
      required: true,
      email: true,
    },
    password: {
      required: true,
      minlength: 8,
    },
    cpassword: {
      equalTo: "#reg_pass",
    },
    contact: {
      required: true,
      number: true,
      minlength: 10,
      maxlength: 10
    },
    zipcode: {
      required: true,
    },
  },
  focusInvalid: false,
  invalidHandler: function (form, validator) {
    if (!validator.numberOfInvalids())
      return;
    $('html, body').animate({
      scrollTop: $(validator.errorList[0].element).offset().top
    }, 1000);
  },
  submitHandler: function (form) {
    var username = $('input[name="username"]').val();
    var url_ = $('input[name="username"]').data('url');
    var csrfmiddlewaretoken = $('input[name="csrfmiddlewaretoken"]').val();
    $.ajax({
      type: 'POST',
      url: url_,
      data: { username: username, csrfmiddlewaretoken: csrfmiddlewaretoken },
      success: function (response) {
        if (response == 'exist') {
          $('.username_exist').remove();
          $('#reg_username').after('<p class="error username_exist">Username already exist</p>')
          $('html, body').animate({
            scrollTop: $('.username_exist').offset().top - 50
          }, 1000);
        } else if (response == 'not exist') {
          form.submit();
        }
      }
    })
  },
})



// LOGIN FORM

// $('#login_form').validate({
//   rules: {
//       username:{
//           required: true,
//       },
//       password:{
//           required: true,
//       },
//   },
//   submitHandler: function(form){
//       form.submit();
//   },
// })



// approval of plan
$('#roc_action_form').validate({
  rules: {
    action_roc: {
      required: true,
    },
    reason_roc: {

      required: true,
    },
    approver_name: {

      required: true,

    },
    sign_roc: {

      required: true,

    },
    date_roc: {

      required: true,
    },
    select_leader: {

      required: true,
    },
    select_member: {

      required: true,
    },
    leader_approver: {

      required: true,
    },
    Member_approver: {

      required: true,
    },
    roc_id: {

      required: true,
    },
  },
  focusInvalid: false,
  invalidHandler: function (form, validator) {
    if (!validator.numberOfInvalids())
      return;
    $('html, body').animate({
      scrollTop: $(validator.errorList[0].element).offset().top
    }, 1000);
  },
  //submitHandler: function(form){
  //     var username = $('input[name="username"]').val();
  //     var url_ = $('input[name="username"]').data('url');
  //     var csrfmiddlewaretoken = $('input[name="csrfmiddlewaretoken"]').val();
  //     $.ajax({
  //         type: 'POST',
  //         url: url_,
  //         data: {username:username, csrfmiddlewaretoken:csrfmiddlewaretoken},
  //         success: function(response){
  //             if(response == 'exist'){
  //                 $('.username_exist').remove();
  //                 $('#reg_username').after('<p class="error username_exist">Username already exist</p>')
  //                 $('html, body').animate({
  //                     scrollTop: $('.username_exist').offset().top - 50
  //                 }, 1000);
  //             }else if(response == 'not exist'){
  //                 form.submit();
  //             }
  //         }
  //     })
  //},
})

function dynInput(cbox) {
  if (cbox.checked) {
    var input = document.createElement("input");
    input.type = "file";
    input.className = "custom-file"
    input.id = "customFile"
    input.name = "businessfile"
    var div = document.createElement("div");
    div.id = cbox.name;

    div.appendChild(input);
    document.getElementById("insertinputs").appendChild(div);
  } else {
    document.getElementById(cbox.name).remove();
  }
}




// $('body').on('change', '#roc_title', function () {
//   let roc_id_data = $(this).val();
//   let csrfmiddlewaretoken = $('input[name="csrfmiddlewaretoken"]').val();
//   $.ajax({
//     type: 'POST',
//     url: 'get-type-of-change/',
//     data: { roc_id: roc_id_data, csrfmiddlewaretoken: csrfmiddlewaretoken },
//     success: function (response) {
      
      
//     }
//   })
// })

$('body').on('change', '#roc_title', function () {
  let roc_id_data = $(this).val();
  let csrfmiddlewaretoken = $('input[name="csrfmiddlewaretoken"]').val();
  $.ajax({
    type: 'POST',
    url: 'get-title/',
    data: { roc_id: roc_id_data, csrfmiddlewaretoken: csrfmiddlewaretoken },
    success: function (response) {
      $('.title_input input').val(response);
      $('.title_approval_input input').val(response);
      $('.title_plan_detail_input input').val(response);
      $('.title_plan_implement_input input').val(response);
      $('.title_roc_verify_input input').val(response);
      $('.title_roc_review_input input').val(response);
      $('.plan_for_change_moc_p_input input').val(response);
      $('.title_plan_detail_moc_p_input input').val(response);
      $('.moc_p_implement_input input').val(response);
      $('.moc_p_verify_input input').val(response);
      $('.moc_p_review_input input').val(response);


    }
  })
})

$('body').on('click', '#roc_detail', function () {
  let user_id_data = $(this).attr('data-id');
  let csrfmiddlewaretoken = $('input[name="csrfmiddlewaretoken"]').val();
  $.ajax({
    type: 'POST',
    traditional: true,
    url: 'get_moc_new',
    data: { id: user_id_data, csrfmiddlewaretoken: csrfmiddlewaretoken },
    success: function (response) {
      console.log(response);
      $('#section_Form').reset;
      $('.modal-body input[name="chngeduration"]').prop('checked', false);
      $('.modal-body input[name="type_of_change"]').prop('checked', false);
      $('.modal-body input[name="title"]').val(response.title);
      $('.modal-body input[name="name"]').val(response.name);
      $('.modal-body input[name="date"]').val(response.date);
      $(".modal-body .type_of_changes .form-check-inline").each(function () {
        if ($(this).find('input').val() == response.type_of_change) {
          $(this).find('input').prop('checked', 'checked');
        }
      });
      if ($('#temprory_modal input').val() == response.changeduration) {
        $('#temprory_modal input').prop('checked', 'checked');
      }
      if ($('#permanent_modal').find("input").val() == response.changeduration) {
        $('#permanent_modal').find("input").prop('checked', 'checked');
      }
      $('.modal-body select[name="months"]').val(response.months);
      $('.modal-body textarea[name="Proposal_changes"]').val(response.Proposal_changes);
      $('.modal-body textarea[name="business_case"]').val(response.business_case);
      $('.modal-body input[name="Datestart"]').val(response.Datestart);
      $('.modal-body input[name="Dateend"]').val(response.Dateend);
      $('.modal-body textarea[name="implications"]').val(response.implications);
      $('.modal-body input[name="Estimate"]').val(response.Estimate);
      $('.modal-body select[name="select_manager"]').val(response.select_manager);
      $('.modal-body select[name="select_manager"]').val(response.select_manager);
      $('.modal-body input[name="id"]').val(response.id);

    }
  })
})

// $(document).on('click','#plan_for_change_btn',function(e){
//   // alert($('#plan_consequense').val());
//       $.ajax({ // create an AJAX call...
//            // get the form data
//           type:'POST', // GET or POST
//           url: 'roc-plan', // the file to call

//           data:{
//             roc_leader:$('.roc_leader').val(),
//             roc_approver:$('.roc_approver').val(),
//             plan_consequense:$('#plan_consequense').val(),
//             plan_stakeholders:$('#stakeholders').val(),
//             stakeholders_document:$('.stakeholders_document').val(),
//             plan_Processes:$('.plan_Processes').val(),
//             Processes_document:$('.Processes_document').val(),
//             plan_information:$('.plan_information').val(),
//             information_document:$('.information_document').val(),
//             plan_training:$('.plan_training').val(),
//             training_document:$('.training_document').val(),
//             csrfmiddlewaretoken:$('input[name="csrfmiddlewaretoken"]').val(),
//       },   
//            cache: false,
//            contentType: false,
//            processData: false,
//            success: function() { // on success..


//              // update the DIV 
//           }
//       });
//       return false;
//   });

// $(document).on('click', '#plan_for_change_btnn', function (e) {
//   var form_data = new FormData();
//   form_data.append('roc_id', $('.roc_id').val()); // ADD DATA
//   form_data.append('roc_approver', $('.roc_approver').val()); // ADD DATA
//   form_data.append('plan_consequense', $('#plan_consequense').val()); // ADD DATA
//   form_data.append('plan_stakeholders', $('#stakeholders').val()); // ADD DATA
//   form_data.append("stakeholders_document", document.getElementById('stakeholders_document_file').files[0]); // ADD FILES
//   form_data.append('plan_Processes', $('.plan_Processes').val()); // ADD DATA
//   form_data.append("Processes_document", document.getElementById('Processes_document_file').files[0]); // ADD FILES
//   form_data.append('plan_information', $('.plan_information').val()); // ADD DATA
//   form_data.append("information_document", document.getElementById('information_document_file').files[0]); // ADD FILES
//   form_data.append('plan_training', $('.plan_training').val()); // ADD DATA
//   form_data.append("training_document", document.getElementById('training_document_file').files[0]); // ADD FILES
//   form_data.append("csrfmiddlewaretoken", $('input[name="csrfmiddlewaretoken"]').val()); // ADD FILES,
//   $.ajax({ // create an AJAX call...
//     // get the form data
//     type: 'POST', // GET or POST
//     url: 'roc-plan', // the file to call
//     data: form_data,
//     cache: false,
//     contentType: false,
//     processData: false,
//     success: function (response) { // on success..
//       if (response == 'save') {
//         data = $('#plan_consequense').val()
//         $.each(data, function (index) {
//           $('#plan_for_change_tbl tr:nth-child(' + (index + 1) + ') td:first-child').html('<input type="text" class="form-control-plaintext consequense_input"  value="' + data[index] + '" readonly="readonly" name="type_consequense">');
//           $('#plan_for_change_tbl tr:nth-child(' + (index + 1) + ') td:nth-child(2').html('<textarea class="form-control" id="mitigation_consequense" row="1" name="mitigation_consequense"></textarea>');
//         });



//       }
//       // update the DIV
//     }
//   });
//   return false;
// });



var index = 1;
function insertRow() {
  var table = document.getElementById("myTable");
  var row = table.insertRow(table.rows.length);
  var cell1 = row.insertCell(0);
  var t1 = document.createElement("input");
  t1.id = "stakeholder_name" + index;
  t1.className = "form-control-plaintext";
  t1.name = "group_stakeholder";
  t1.placeholder = "Group";
  cell1.appendChild(t1);
  var cell2 = row.insertCell(1);
  var t2 = document.createElement("textarea");
  t2.id = "stakeholders_upadte" + index;
  t2.className = "stakeholdertext_update";
  t2.name = "stakeholdertext_update";
  t2.rows = "1";
  cell2.appendChild(t2);
  var cell3 = row.insertCell(2);
  var t3 = document.createElement("textarea");
  t3.id = "stakeholders_assigned" + index;
  t3.className = "stakeholdertext_assigned";
  t3.name = "stakeholdertext_assigned";
  t3.rows = "1";
  cell3.appendChild(t3);
  var cell4 = row.insertCell(3);
  var t4 = document.createElement("input")
  t4.className = "button-add-delete"
  t4.type = "button"
  t4.id = "btn-delete"
  t4.value = "delete"
  cell4.appendChild(t4);
  $('#myTable tr:first-child td:nth-child(4)').attr('rowspan', index + 1);
  index++;

}

$('#myTable').on('click', '#btn-delete', function () {
  $(this).closest('tr').remove();
})

var add_ = 1;
function insertProcedureRow() {

  $('#procedure_table').append('<tr> <td> <div class="form-group"> <input type="text" class="form-control-plaintext" id="procedure_name' + add_ + '" placeholder="Procedure" name="type_procedure[]"> </div> <div class="custom-file"> <input type="file" class="custom-file-input" name="procedure_doc" id="procedure_file" multiple="multiple"> <label class="custom-file-label" for="customFile">Choose file</label> </div> </td> <td> <div class="form-group"> <label for="comment"></label> <textarea class="form-control" rows="1" id="procedure_update_id' + add_ + '" name="procedure_update[]"></textarea> </div> </td> <td> <div class="form-group"> <label for="comment"></label> <textarea class="form-control" rows="1" id="procedure_assigned_id' + add_ + '" name="procedure_assigned[]"></textarea> </div> <td><input type="button" id="#btn-delete-procedure" class="button-add-delete" " value="delete"></input>');
  add_++;
}





$('#procedure_table').on('click', '.button-add-delete', function () {
  $(this).closest('tr').remove();

})

var document_index = 1;
function insertDocumenteRow() {

  $('#document_table').append('<tr> <td> <div class="form-group"> <input type="text" class="form-control-plaintext" id="document_name' + document_index + '" placeholder="Document" name="type_document[]"> </div> <div class="custom-file"> <input type="file" class="custom-file-input" name="document_doc" id="document_file" multiple="multiple"> <label class="custom-file-label" for="customFile">Choose file</label> </div> </td> <td> <div class="form-group"> <label for="comment"></label> <textarea class="form-control" rows="1" id="document_update_id' + document_index + '" name="document_update[]"></textarea> </div> </td> <td> <div class="form-group"> <label for="comment"></label> <textarea class="form-control" rows="1" id="document_assigned_id' + document_index + '" name="document_assigned[]"></textarea> </div> <td><input type="button" id="#btn-delete-document" class="button-add-delete" " value="delete"></input>');
  document_index++;
}





$('#document_table').on('click', '.button-add-delete', function () {
  $(this).closest('tr').remove();

})

var training_index = 1;
function insertTrainingeRow() {

  $('#training_table').append('<tr> <td> <div class="form-group"> <input type="text" class="form-control-plaintext" id="training_name' + training_index + '" placeholder="Training focus" name="type_training[]"> </div> <div class="custom-file"> <input type="file" class="custom-file-input" name="training_doc" id="training_file" multiple="multiple" > <label class="custom-file-label" for="customFile">Choose file</label> </div> </td> <td> <div class="form-group"> <label for="comment"></label> <textarea class="form-control" rows="1" id="training_update_id' + training_index + '" name="training_update[]"></textarea> </div> </td> <td> <div class="form-group"> <label for="comment"></label> <textarea class="form-control" rows="1" id="training_assigned_id' + training_index + '" name="training_assigned[]"></textarea> </div> <td><input type="button" id="#btn-delete-document" class="button-add-delete" " value="delete"></input>');
  training_index++;
}


$('#training_table').on('click', '.button-add-delete', function () {
  $(this).closest('tr').remove();

})

$('.custom-file-input').on('change',function(){
  //get the file name
  var fileName = $(this).val();
  //replace the "Choose a file" label
  $(this).next('.custom-file-label ').html(fileName);
})




// //approval to implememt validation
// $('#moc_implement_action').validate({
//   rules: {
//     role_user: {
//       required: true,
//     },
//     action_implement_roc: {

//       required: true,
//     },
//     comments_implementation: {

//       required: true,

//     },
//     Approver_Name_implement: {

//       required: true,

//     },
//     Approver_sign_implement: {

//       required: true,
//     },
//     implement_date: {

//       required: true,
//    },
//     roc_id_implement: {

//        required: true,
//     },
  
//   },
//   focusInvalid: false,
//   invalidHandler: function (form, validator) {
//     if (!validator.numberOfInvalids())
//       return;
//     $('html, body').animate({
//       scrollTop: $(validator.errorList[0].element).offset().top
//     }, 1000);
//   },
 
// })



// //moc verification form
// $('#verification_moc').validate({
//   rules: {
//     roc_id_verify: {
//       required: true,
//     },
//     training_verified: {

//       required: true,
//     },
//     procedures_verified: {

//       required: true,

//     },
//     documentation_verified: {

//       required: true,

//     },
//     other_action: {

//       required: true,
//     },
   
  
//   },
//   focusInvalid: false,
//   invalidHandler: function (form, validator) {
//     if (!validator.numberOfInvalids())
//       return;
//     $('html, body').animate({
//       scrollTop: $(validator.errorList[0].element).offset().top
//     }, 1000);
//   },
 
// })

//radio button in review ==>if no coorective action will appear
$(document).ready(function() {
  $('input[type="radio"]').click(function() {
      if($(this).attr('id') == 'no_corrective') {
           $('#show-me').show();           
      }
      else {
           $('#show-me').hide();   
      }
  });
});





// $('#moc_review_form').validate({
//   rules: {
//     roc_id_review: {
//       required: true,
//     },
//     moc_closure: {

//       required: true,
//     },
//     effectiveness_review: {

//       required: true,

//     },
//     reviewer_name: {

//       required: true,

//     },
//     reviewer_signature: {

//       required: true,
//     },
//     review_date: {

//       required: true,
//    },
    
  
//   },
//   focusInvalid: false,
//   invalidHandler: function (form, validator) {
//     if (!validator.numberOfInvalids())
//       return;
//     $('html, body').animate({
//       scrollTop: $(validator.errorList[0].element).offset().top
//     }, 1000);
//   },
 
// })



// $(".roc_title").change(function(event) { 
//   event.preventDefault(); 
//   $('.Disable').removeAttr("disabled")
// });

// $(document).ready(function(){
//   $("#roc_title").change(function(event){
//     event.preventDefault(); 
//     $('.Disable').removeAttr("disabled")
//   });
// });






var selected_option = $('#roc_title option:selected');
$("body").on('change', '#roc_title', function() { 
  
  if($(this).val() != ''){
    $('#approval_submit').removeClass("Disable");
    $('#plan_for_change_btn').removeClass("Disable");
    $('#plan_detail_submit').removeClass("Disable");
    $('#implement_submit').removeClass("Disable");
    $('#verify_submit').removeClass("Disable");
    $('#review_submit').removeClass("Disable");
    $('#moc_p_plan_change_btn').removeClass("Disable");
}
else{
  $('#approval_submit').addClass("Disable")
  $('#plan_for_change_btn').addClass("Disable");
  $('#plan_detail_submit').addClass("Disable");
  $('#implement_submit').addClass("Disable");
  $('#verify_submit').addClass("Disable");
  $('#review_submit').addClass("Disable");
  $('#moc_p_plan_change_btn').addClass("Disable");
}
if($(this).val() != ''){
  
  let status = $(this).find(":selected").attr('data-status');
  let type = $(this).find(":selected").attr('data-type');
  $('.type_change_input input').val(type);
  if(type == 'Personnel'){
    $('#moc-other-div').css('display','none');
    $('#moc-p-form-div').css('display','block');
  }else{
    $('#moc-p-form-div').css('display','none');
    $('#moc-other-div').css('display','block');
  }
  let roc_id = $(this).val();
  let form_id = false;
  
  if(status == 0){
    form_id = 'roc_action_form';
  }
  if(status == 1 && type == 'Personnel'){
    form_id = 'plan_for_change_moc_p';
  }
  if(status == 1 && type != 'Personnel'){
    form_id = 'plan_for_changes';
  }

  if(status == 2 && type == 'Personnel' ){
    $.post( "get_plan_for_change", { type: type, roc_id: roc_id, "csrfmiddlewaretoken": $('input[name="csrfmiddlewaretoken"]').val() })
    .done(function( data ) {
      let count = 1;
      $.each(data, function(index){
        $('#moc_p_plan_for_change_tbl tr:nth-child('+(count)+')').find('td:first-child').html('<input type="text" class="form-control-plaintext consequense_input"  value="' + data[index] + '" readonly="readonly" name="type_moc_p_consequense[]">');
        $('#moc_p_plan_for_change_tbl tr:nth-child('+count+')').find('td:nth-child(2)').html('<textarea class="form-control" id="mitigation_moc_p_consequense" row="1" name="mitigation_moc_p_consequense[]"></textarea>');
        count++;
      })
      // alert( "Data Loaded: " + data );
    });
    form_id = 'moc_p_plan_for_change__detail_form';
  }
  if(status == 2 && type != 'Personnel'){
    $.post( "get_plan_for_change", { type: type, roc_id: roc_id, "csrfmiddlewaretoken": $('input[name="csrfmiddlewaretoken"]').val() })
    .done(function( data ) {
      let count = 1;
      $.each(data, function(index){
        $('#plan_for_change_tbl tr:nth-child('+(count)+')').find('td:first-child').html('<input type="text" class="form-control-plaintext consequense_input"  value="' + data[index] + '" readonly="readonly" name="type_consequense[]">');
        $('#plan_for_change_tbl tr:nth-child('+count+')').find('td:nth-child(2)').html('<textarea class="form-control" id="mitigation_consequense" row="1" name="mitigation_consequense[]"></textarea>');
        count++;
      })
      // alert( "Data Loaded: " + data );
    });
    form_id = 'plan_for_change__detail_form';
  }
  if(status == 3 && type == 'Personnel'){
    form_id = 'approval_implement_moc_p';
  }
  if(status == 3 && type != 'Personnel' ){
    form_id = 'approval_to_implement';
  }
  if(status == 4 && type == 'Personnel' ){
    form_id = 'moc_p_verification';
  }
  if(status == 4 && type != 'Personnel'){
    form_id = 'pssr_module';
  }
  if(status == 5 && type != 'Personnel'){
    form_id = 'verification_moc';
  }
  if(status == 5 && type == 'Personnel'){
    form_id = 'review_moc_p_form';
  }
  if(status == 6){
    form_id = 'moc_review_form';
  }
  if(status == 7){
    alert("MOC already Completed Download the report from report section");
  }
  if(form_id){
    alert(form_id);
    $('html, body').animate({
      scrollTop: $("#"+form_id).offset().top
    }, 1000);
  }
}
});

$('#approval_submit').on('click',function(e){
  if( $(this).hasClass('Disable') ){
      e.preventDefault();
      alert('please select request of change')
  }else{
    $('#roc_action_form').validate({
      rules: {
        action_roc: {
          required: true,
        },
        reason_roc: {
    
          required: true,
        },
        approver_name: {
    
          required: true,
    
        },
        sign_roc: {
    
          required: true,
    
        },
        date_roc: {
    
          required: true,
        },
        select_leader: {
    
          required: true,
        },
        select_member: {
    
          required: true,
        },
        leader_approver: {
    
          required: true,
        },
        Member_approver: {
    
          required: true,
        },
        roc_id: {
    
          required: true,
        },
      },
      focusInvalid: false,
      invalidHandler: function (form, validator) {
        if (!validator.numberOfInvalids())
          return;
        $('html, body').animate({
          scrollTop: $(validator.errorList[0].element).offset().top
        }, 1000);
      },
      
    })
  };
  });


  $('#plan_for_change_btn').on('click',function(e){
    if( $(this).hasClass('Disable') ){
        e.preventDefault();
        alert('please select request of change')
    }else{
      $('#plan_for_change_form').validate({
      rules: {
        roc_id: {
          required: true,
        },
        plan_consequense: {
    
          required: true,
        },
        plan_stakeholders: {
    
          required: true,
    
        },
        plan_Processes: {
    
          required: true,
    
        },
        plan_information: {
    
          required: true,
        },
        plan_training: {
    
          required: true,
        },
        
      },
      focusInvalid: false,
      invalidHandler: function (form, validator) {
        if (!validator.numberOfInvalids())
          return;
        $('html, body').animate({
          scrollTop: $(validator.errorList[0].element).offset().top
        }, 1000);
      },
      submitHandler: function(form){
        var form_data = new FormData();
        form_data.append('roc_id', $('.roc_id').val()); // ADD DATA
        form_data.append('roc_approver', $('.roc_approver').val()); // ADD DATA
        form_data.append('plan_consequense', $('#plan_consequense').val()); // ADD DATA
        form_data.append('plan_stakeholders', $('#stakeholders').val()); // ADD DATA
        form_data.append("stakeholders_document", document.getElementById('stakeholders_document_file').files[0]); // ADD FILES
        form_data.append('plan_Processes', $('.plan_Processes').val()); // ADD DATA
        form_data.append("Processes_document", document.getElementById('Processes_document_file').files[0]); // ADD FILES
        form_data.append('plan_information', $('.plan_information').val()); // ADD DATA
        form_data.append("information_document", document.getElementById('information_document_file').files[0]); // ADD FILES
        form_data.append('plan_training', $('.plan_training').val()); // ADD DATA
        form_data.append("training_document", document.getElementById('training_document_file').files[0]); // ADD FILES
        form_data.append("csrfmiddlewaretoken", $('input[name="csrfmiddlewaretoken"]').val()); // ADD FILES,
        $.ajax({ // create an AJAX call...
          // get the form data
          type: 'POST', // GET or POST
          url: 'roc-plan', // the file to call
          data: form_data,
          cache: false,
          contentType: false,
          processData: false,
          success: function (response) { // on success..
            if (response == 'save') {
              data = $('#plan_consequense').val()
              $.each(data, function (index) {
                $('#plan_for_change_tbl tr:nth-child(' + (index + 1) + ') td:first-child').html('<input type="text" class="form-control-plaintext consequense_input"  value="' + data[index] + '" readonly="readonly" name="type_consequense[]">');
                $('#plan_for_change_tbl tr:nth-child(' + (index + 1) + ') td:nth-child(2').html('<textarea class="form-control" id="mitigation_consequense" row="1" name="mitigation_consequense[]"></textarea>');
              });



            }
            // update the DIV
          }
        });
      }
  
    })
     
    };
    });


    $('#plan_detail_submit').on('click',function(e){
      if( $(this).hasClass('Disable') ){
          e.preventDefault();
          alert('please select request of change')
      }else{
        $('#plan_for_change__detail_form').validate({
          rules: {
            mitigation_consequense: {
              required: true,
            },
            additional_study: {
        
              required: true,
            },
            inspection_require: {
        
              required: true,
        
            },
            pha_require: {
        
              required: true,
        
            },
          
          },
          focusInvalid: false,
          invalidHandler: function (form, validator) {
            if (!validator.numberOfInvalids())
              return;
            $('html, body').animate({
              scrollTop: $(validator.errorList[0].element).offset().top
            }, 1000);
          },
          
        })
      };
      });
    
      $('#implement_submit').on('click',function(e){
        if( $(this).hasClass('Disable') ){
            e.preventDefault();
            alert('please select request of change')
        }else{
             //approval to implememt validation
            $('#moc_implement_action').validate({
            rules: {
            role_user: {
            required: true,
            },
            action_implement_roc: {

            required: true,
            },
            comments_implementation: {

            required: true,

            },
            Approver_Name_implement: {

            required: true,

            },
            Approver_sign_implement: {

            required: true,
            },
            implement_date: {

            required: true,
            },
            roc_id_implement: {

            required: true,
            },
  
          },
            focusInvalid: false,
            invalidHandler: function (form, validator) {
            if (!validator.numberOfInvalids())
            return;
            $('html, body').animate({
            scrollTop: $(validator.errorList[0].element).offset().top
            }, 1000);
          },
 
       })

 };
});




$('#verify_submit').on('click',function(e){
  if( $(this).hasClass('Disable') ){
      e.preventDefault();
      alert('please select request of change')
  }else{
    //moc verification form
     $('#verification_moc').validate({
       rules: {
         roc_id_verify: {
           required: true,
         },
         training_verified: {

           required: true,
         },
         procedures_verified: {

           required: true,

         },
         documentation_verified: {

           required: true,

         },
         other_action: {

           required: true,
         },
   
  
       },
       focusInvalid: false,
       invalidHandler: function (form, validator) {
         if (!validator.numberOfInvalids())
           return;
         $('html, body').animate({
           scrollTop: $(validator.errorList[0].element).offset().top
         }, 1000);
        },
 
      })

};
});



$('#review_submit').on('click',function(e){
  if( $(this).hasClass('Disable') ){
      e.preventDefault();
      alert('please select request of change')
  }else{
    $('#moc_review_form').validate({
      rules: {
        roc_id_review: {
          required: true,
        },
        moc_closure: {
    
          required: true,
        },
        effectiveness_review: {
    
          required: true,
    
        },
        reviewer_name: {
    
          required: true,
    
        },
        reviewer_signature: {
    
          required: true,
        },
        review_date: {
    
          required: true,
       },
        
      
      },
      focusInvalid: false,
      invalidHandler: function (form, validator) {
        if (!validator.numberOfInvalids())
          return;
        $('html, body').animate({
          scrollTop: $(validator.errorList[0].element).offset().top
        }, 1000);
      },
     
    })
    
   
  };
  });





// plan for change moc-p form

  $('#moc_p_plan_change_btn').on('click',function(e){
    if( $(this).hasClass('Disable') ){
        e.preventDefault();
        alert('please select request of change')
    }else{
      $('#plan_for_change_moc_p').validate({
      rules: {
        basis_for_change: {

         required: true,
        },
        technical_review: {
    
          required: true,
    
        },
        risk_review: {
    
          required: true,
    
        },
        environmental_review: {
    
          required: true,
        },
        regulatory_review: {
    
          required: true,
        },
        
      },
      focusInvalid: false,
      invalidHandler: function (form, validator) {
        if (!validator.numberOfInvalids())
          return;
        $('html, body').animate({
          scrollTop: $(validator.errorList[0].element).offset().top
        }, 1000);
      },
      submitHandler: function(form){
        var form_data = new FormData();
        form_data.append('roc_id', $('.roc_id').val()); // ADD DATA
        
        form_data.append('basis_for_change', $('#basis_for_change').val()); // ADD DATA
        form_data.append('technical_review', $('#technical_review').val()); // ADD DATA
        form_data.append("technical_review_document", document.getElementById('technical_review_document').files[0]); // ADD FILES
        form_data.append('risk_review', $('#risk_review').val()); // ADD DATA
        form_data.append("risk_review_document", document.getElementById('risk_review_document').files[0]); // ADD FILES
        form_data.append('environmental_review', $('#environmental_review').val()); // ADD DATA
        form_data.append("environmental_review_document", document.getElementById('environmental_review_document').files[0]); // ADD FILES
        form_data.append('regulatory_review', $('#regulatory_review').val()); // ADD DATA
        form_data.append("regulatory_review_document", document.getElementById('regulatory_review_document').files[0]); // ADD FILES
        form_data.append("csrfmiddlewaretoken", $('input[name="csrfmiddlewaretoken"]').val()); // ADD FILES,
        $.ajax({ // create an AJAX call...
          // get the form data
          type: 'POST', // GET or POST
          url: 'roc_p_plan', // the file to call
          data: form_data,
          cache: false,
          contentType: false,
          processData: false,
          success: function (response) { // on success..
            if (response == 'save') {
              data = $('#basis_for_change').val()
              $.each(data, function (index) {
                $('#moc_p_plan_for_change_tbl tr:nth-child(' + (index + 1) + ') td:first-child').html('<input type="text" class="form-control-plaintext consequense_input"  value="' + data[index] + '" readonly="readonly" name="type_moc_p_consequense[]">');
                $('#moc_p_plan_for_change_tbl tr:nth-child(' + (index + 1) + ') td:nth-child(2)').html('<textarea class="form-control" id="mitigation_moc_p_consequense" row="1" name="mitigation_moc_p_consequense[]"></textarea>');
              });



            }
            // update the DIV
          }
        });
      }
  
    })
     
    };
    });


// moc-p plan for change detail add row function



    var index = 1;
function insertRowMOCP(this_) {
  let row_len = $('.moc-p-tech-row').length;
  alert(row_len);
  $('#myTableMOCP tr:first-child td:nth-child(4)').attr('rowspan',row_len+1);
  $('.moc-p-tech-row').last().after('<tr class="moc-p-tech-row"> <td> <div class="form-group"> <input type="text" id="Technical_Impact_name" class="form-control-plaintext" placeholder="Technical Impact" name="Technical_Impact_count[]"> </div> </td> <td> <div class="form-group"> <label for="comment"></label> <textarea class="form-control stakeholdertext_update " rows="1" id="reason_of_imapct" name="reason_of_imapct[]"></textarea> </div> </td> <td> <div class="form-group"> <label for="comment"></label> <textarea class="form-control stakeholdertext_assigned" rows="1" id="proposed_mitigation_impact" name="proposed_mitigation_impact[]"></textarea> </div> </td> <td><input type="button" id="btnAddrow1" class="remove-tech-row button-add" value="Remove"> </td> </tr>')


}

$('body').on('click','.remove-tech-row',function(){
  let row_len = $('.moc-p-tech-row').length;
  $(this).parent().parent().remove();
  $('#myTableMOCP tr:first-child td:nth-child(4)').attr('rowspan',row_len-1);
})

var add_ = 1;
function insertHazardRow(this_) {
  let row_len = $('.my_moc-p_risk_row').length;
  alert(row_len);

  $('#my_moc-p_risk_table tr:first-child td:nth-child(4)').attr('rowspan',row_len+1);
  $('.my_moc-p_risk_row').last().after('<tr class="my_moc-p_risk_row"><td><div class="form-group"><input class="form-control-plaintext" id="Risk_count'+add_+'" name="Risk_count[]" placeholder="Hazards and Risks"></div></td><td><div class="form-group"><label for="comment"></label> <textarea class="form-control stakeholdertext_update" id="Risk_count_mitigation'+add_+'" name="Risk_count_mitigation[]" rows="1"></textarea></div></td><td><div class="form-group"><label for="comment"></label> <textarea class="form-control stakeholdertext_assigned" id="Risk_count_assigned'+add_+'" name="Risk_count_assigned[]" rows="1"></textarea></div></td><td><input class="remove-hazard-row button-add" id="btnAddrow2" type="button" value="Remove"></td></tr>');
  add_++;
}
$('body').on('click','.remove-hazard-row',function(){
  let row_len = $('.my_moc-p_risk_row').length;
  $(this).parent().parent().remove();
  $('#my_moc-p_risk_table tr:first-child td:nth-child(4)').attr('rowspan',row_len-1);
})

var env_index = 1;
function insertEnvRow() {
  let row_len = $('.my_moc-p_risk_row').length;
  $('#my_moc-p_environment_table tr:first-child td:nth-child(4)').attr('rowspan',row_len+1);
  $('.my_moc-p_environment_row').last().after('<tr class="my_moc-p_environment_row"><td><div class="form-group"><input class="form-control-plaintext" id="Environmental Impact'+ env_index +' name="Environmental_Impact_count[]" placeholder="Environmental Impact"></div><td><div class="form-group"><label for="comment"></label> <textarea class="form-control stakeholdertext_update" id="Environmental_Impact_mitigation'+ env_index +'" name="Environmental_Impact_mitigation[]" rows="1"></textarea></div><td><div class="form-group"><label for="comment"></label> <textarea class="form-control stakeholdertext_assigned" id="Environmental Impact_assigned'+ env_index +'" name="Environmental_Impact_assigned[]" rows="1"></textarea></div><td><input  class="remove-env-row button-add" id="btnAddrow3" type="button" value="Remove"></td>');
  env_index++;
}

$('body').on('click','.remove-env-row',function(){
  let row_len = $('.my_moc-p_environment_row').length;
  $(this).parent().parent().remove();
  $('#my_moc-p_environment_table tr:first-child td:nth-child(4)').attr('rowspan',row_len-1);
})





var regulatory_index = 1;
function insertRegulatoryRow() {
  let row_len = $('.my_moc-p_Regulatory_row').length;
  $('#my_moc-p_Regulatory_table tr:first-child td:nth-child(4)').attr('rowspan',row_len+1);

  $('.my_moc-p_Regulatory_row').last().after('<tr class="my_moc-p_Regulatory_row"><td><div class="form-group"><input class="form-control-plaintext" id="Regulatory Concerns'+ regulatory_index +'" name="Regulatory_Concerns_count[]" placeholder="Regulatory Concerns"></div><td><div class="form-group"><label for="comment"></label> <textarea class="form-control stakeholdertext_update" id="Regulatory Concerns_mitigation'+ regulatory_index +' "name="Regulatory_Concerns_mitigation[]" rows="1"></textarea></div><td><div class="form-group"><label for="comment"></label> <textarea class="form-control stakeholdertext_assigned" id="Regulatory_Impact_assigned'+ regulatory_index +'" name="Regulatory_Concerns_assigned[]" rows="1"></textarea></div><td><input class="remove-regulatory-row button-add" id="btnAddrow4" type="button" value="Remove"></td>');
  regulatory_index++;
}


$('body').on('click','.remove-regulatory-row',function(){
  let row_len = $('.my_moc-p_Regulatory_row').length;
  $(this).parent().parent().remove();
  $('#my_moc-p_Regulatory_table tr:first-child td:nth-child(4)').attr('rowspan',row_len-1);
})


