from django.db import models


# Create your models here.
OPTIONS = (
    
    ('1','1'),
    ('2','2'),
    ('3','3'), 
    ('4','4'),
    ('5','5'),
    ('6','6'),
    ('7','7'),
    ('8','8'),
    ('9','9'),
    ('10','10'),
    ('11','11'),
    ('12','12'),
    )
duration= (
    ('temprory','temprory'),
    ('peramnent','peramnent'),
)

changes=(
    ('Business Process','Business Process'),
    ('Technology','Technology'),
    ('Chemical','Chemical'),
    ('Equipment/facility','Equipment/Facility'),
    ('Personnel','Personnel'),
    ('Product','Product'),
    ('Other','Other'),
)

class moc_new(models.Model):  
    title= models.CharField(max_length=100, blank= False, null = False)
    name = models.CharField(max_length=100 , blank= False, null = False )  
    date = models.DateField(auto_now_add=True , blank= False, null = False)
    type_of_change = models.CharField(max_length=50, choices=changes , blank= False, )
    businessfile=models.FileField(upload_to='businessfile/', default='')
    changeduration = models.CharField(max_length=50, choices=duration)
    months = models.CharField(max_length=2,choices=OPTIONS)
    Proposal_changes= models.TextField( blank= False, null = False)
    business_case= models.TextField(blank= False, null = False) 
    Datestart=models.DateField(auto_now_add=True , blank= False, null = False)
    Dateend=models.DateField(auto_now_add=True , blank= False, null = False)
    implications=models.TextField(blank= False, null = False) 
    Estimate=models.CharField(max_length=20 , blank= False, null = False)
    select_manager= models.CharField(max_length=100)
    user_id=models.IntegerField()
    status_of_form=models.PositiveSmallIntegerField(default = 0)
    status=models.PositiveSmallIntegerField(default = 0)
    status_implement=models.PositiveSmallIntegerField(default = 0)
    class Meta:  
        db_table = "moc_new"
    def __str__(self):
        return self.title      

class standard_user(models.Model):
    objects = None
    id = models.AutoField(primary_key=True)
    username = models.CharField(max_length=100, blank=True)
    name = models.CharField(max_length=100, blank=True)
    email = models.CharField(max_length=100, blank=True)
    password = models.CharField(max_length=100, blank=True)
    contact = models.CharField(max_length=100, blank=True)
    address = models.CharField(max_length=100, blank=True)
    image = models.CharField(max_length=100, blank=True)
    zipcode = models.CharField(max_length=100, blank=True)
    dob = models.CharField(max_length=100, blank=True)
    role_id = models.IntegerField()
    status = models.IntegerField()
    register_date = models.DateTimeField(auto_now_add=True)
    

    class Meta:
        db_table = "moc_user"

    def __str__(self):
        return self.username

class approval_of_plan(models.Model):
    id= models.AutoField(primary_key=True)
    action_roc=models.CharField(max_length=50, blank= False )
    reason_roc=models.TextField(blank= False) 
    approver_name=models.CharField(max_length=100,blank=False)
    sign_roc=models.CharField(max_length=50, blank=False)
    date_roc=models.DateField(auto_now_add=True , blank= False)
    select_leader=models.CharField(max_length=100,blank=False)
    select_member=models.CharField(max_length=100,blank=False)
    roc=models.ForeignKey(moc_new, on_delete=models.CASCADE)
    user=models.ForeignKey(standard_user, on_delete=models.CASCADE)

    class Meta:
        db_table = "approval_of_plan"

    def __str__(self):
        return self.action_roc


class plan_for_change(models.Model):
    id= models.AutoField(primary_key=True)
    roc=models.ForeignKey(moc_new, on_delete=models.CASCADE)
    user=models.ForeignKey(standard_user, on_delete=models.CASCADE)
    plan_consequense=models.CharField(max_length=100,blank=False)
    plan_stakeholders=models.TextField(blank=False)
    stakeholders_document =models.FileField(upload_to='stakeholders_document/', default='')
    plan_Processes=models.TextField(blank=False)
    Processes_document=models.FileField(upload_to='Processes_document/', default='')
    plan_information=models.TextField(blank=False)
    information_document=models.FileField(upload_to='information_document/', default='')
    plan_training=models.TextField(blank=False)
    training_document=models.FileField(upload_to='training_document/', default='')

    class Meta:
        db_table = "plan_for_change"


response=(
    ('yes','yes'),
    ('no','no'),
)
inspection=(
    ('yes','yes'),
    ('no','no'),
)
pha=(
    ('yes','yes'),
    ('no','no'),
)
class plan_for_change_detail(models.Model):
    # consequense table
    id=models.AutoField(primary_key=True) 
    type_consequense=models.CharField(max_length=100,blank=False)
    mitigation_consequense=models.TextField(blank=False)
    consequences_doc=models.FileField(upload_to='consequences_doc/', default='')
    # stakholder_table
    group_stakeholder=models.CharField(max_length=100,blank=False)
    reason_of_impact=models.TextField(blank=False)
    proposed_mitigation=models.TextField(blank=False)
    entire_stakeholdertext_doc=models.FileField(upload_to='stakeholders_document/',default='')
    additional_study=models.CharField(max_length=50, choices=response , blank= True, null=True)
    # procedure table
    type_procedure=models.CharField(max_length=100,blank=False)
    # procedure_doc=models.FileField(upload_to='Processes_document/',default='')
    procedure_doc=models.TextField()
    procedure_update=models.TextField(blank=False)
    procedure_assigned=models.TextField(blank=False)
    entire_procedure_doc=models.FileField(upload_to='Processes_document/',default='')
    # information document table
    type_document=models.CharField(max_length=100,blank=False)
    # document_doc=models.FileField(upload_to='information_document/',default='')
    document_doc=models.TextField()
    document_update=models.TextField(blank=False)
    document_assigned=models.TextField(blank=False)
    entire_document_doc=models.FileField(upload_to='information_document/',default='')
    # training table
    type_training=models.CharField(max_length=100,blank=False)
    # training_doc=models.FileField(upload_to='training_document/',default='')
    training_doc=models.TextField()
    training_update=models.TextField(blank=False)
    training_assigned=models.TextField(blank=False)
    entire_training_doc=models.FileField(upload_to='training_document/',default='')

    inspection_require=models.CharField(max_length=50, choices=inspection , blank=True, null= True )
    pha_require=models.CharField(max_length=50, choices=pha , blank= True, null= True )
    roc=models.ForeignKey(moc_new, on_delete=models.CASCADE)
    user=models.ForeignKey(standard_user, on_delete=models.CASCADE)
    class Meta:
        db_table = "plan_for_change_detail"

class approval_to_implement(models.Model):
    id= models.AutoField(primary_key=True)
    role_user=models.CharField(max_length=50,blank=False)
    action_implement_roc=models.CharField(max_length=50, blank= False )
    comments_implementation=models.TextField(blank= False) 
    Approver_Name_implement=models.CharField(max_length=100,blank=False)
    Approver_sign_implement=models.CharField(max_length=50, blank=False)
    implement_date=models.DateField(auto_now_add=True , blank= False)
    roc=models.ForeignKey(moc_new, on_delete=models.CASCADE)
    user=models.ForeignKey(standard_user, on_delete=models.CASCADE)

    class Meta:
        db_table = "approval_to_implement"

    def __str__(self):
        return self.action_implement_roc



verify1=(
    ('yes','yes'),
    ('no','no'),
)
verify2=(
    ('yes','yes'),
    ('no','no'),
)
verify3=(
    ('yes','yes'),
    ('no','no'),
)
verify4=(
    ('yes','yes'),
    ('no','no'),
)

class verification_moc(models.Model):
    id= models.AutoField(primary_key=True)
    training_verified=models.CharField(max_length=50, choices=verify1 , blank= False, null= True )
    procedures_verified=models.CharField(max_length=50, choices=verify2 , blank= False, null= True )
    documentation_verified=models.CharField(max_length=50, choices=verify3 , blank= False, null= True  )
    other_action=models.CharField(max_length=50, choices=verify4 , blank= False, null= True  )
    roc=models.ForeignKey(moc_new, on_delete=models.CASCADE)
    user=models.ForeignKey(standard_user, on_delete=models.CASCADE)
    
    class Meta:
        db_table = "verification_moc"

    def __str__(self):
        return self.training_verified



class review_moc(models.Model):
    id= models.AutoField(primary_key=True)
    moc_closure=models.TextField(blank=False)
    effectiveness_review=models.TextField(blank=False)
    reviewer_name=models.CharField(max_length=100, blank= False )
    reviewer_signature=models.CharField(max_length=100, blank= False )
    review_date=models.DateField(auto_now_add=True , blank= False)
    roc=models.ForeignKey(moc_new, on_delete=models.CASCADE)
    user=models.ForeignKey(standard_user, on_delete=models.CASCADE)
    
    class Meta:
        db_table = "review_moc"

    def __str__(self):
        return self.moc_closure       

   #moc p-form-complete-models
   #plan for change moc-p
class plan_for_change_moc_p(models.Model):
    id= models.AutoField(primary_key=True)
    roc=models.ForeignKey(moc_new, on_delete=models.CASCADE)
    user=models.ForeignKey(standard_user, on_delete=models.CASCADE)
    basis_for_change=models.CharField(max_length=100,blank=False)
    technical_review=models.TextField(blank=False)
    technical_review_document =models.FileField(upload_to='technical_review_document/', default='')
    risk_review=models.TextField(blank=False)
    risk_review_document=models.FileField(upload_to='risk_review_document/', default='')
    environmental_review=models.TextField(blank=False)
    environmental_review_document=models.FileField(upload_to='environmental_review_document/', default='')
    regulatory_review=models.TextField(blank=False)
    regulatory_review_document=models.FileField(upload_to='regulatory_review_document/', default='')

    class Meta:
        db_table = "plan_for_change_moc_p"


#plan for change detail moc-p
response=(
    ('yes','yes'),
    ('no','no'),
)
inspection=(
    ('yes','yes'),
    ('no','no'),
)
pha=(
    ('yes','yes'),
    ('no','no'),
)
class plan_for_change_moc_p_detail(models.Model):
    # basis for change table
    id=models.AutoField(primary_key=True) 
    type_moc_p_consequense=models.CharField(max_length=100,blank=False)
    mitigation_moc_p_consequense=models.TextField(blank=False)
    moc_p_consequences_doc=models.FileField(upload_to='moc_p_consequences_doc/', default='')
    # Technical Review
    Technical_Impact_count=models.CharField(max_length=100,blank=False)
    reason_of_impact=models.TextField(blank=False)
    proposed_mitigation_impact=models.TextField(blank=False)
    entire_technical_doc=models.FileField(upload_to='technical_review_document/',default='')
    
    technical_risks_impact=models.TextField(blank=False)
    technical_risks_impact_mitigation=models.TextField(blank=False)
    technical_risks_impact_doc=models.FileField(upload_to='technical_risks_impact_doc/', default='')
    
    financial_impact=models.TextField(blank=False)
    financial_impact_mitigation=models.TextField(blank=False)
    financial_impact_doc=models.FileField(upload_to='financial_impact_doc/', default='')
    
    stratagic_impact=models.TextField(blank=False)
    stratagic_impact_mitigation=models.TextField(blank=False)
    stratagic_impact_doc=models.FileField(upload_to='stratagic_imapact_doc/', default='')
    
    assesment_impact=models.TextField(blank=False)
    assesment_impact_mitigation=models.TextField(blank=False)
    assesment_impact_doc=models.FileField(upload_to='assesment_impact_doc/', default='')

    additional_study=models.CharField(max_length=50, choices=response , blank= True, null=True)

    # Hazard table
    Risk_count=models.CharField(max_length=100,blank=False)
    Risk_count_mitigation=models.TextField(blank=False)
    Risk_count_assigned=models.TextField(blank=False)
    entire_Risk_doc=models.FileField(upload_to='risk_review_document/',default='')
    
    # environment table
    Environmental_Impact_count=models.CharField(max_length=100,blank=False)
    Environmental_Impact_mitigation=models.TextField(blank=False)
    Environmental_Impact_assigned=models.TextField(blank=False)
    entire_Environmental_Impact_doc=models.FileField(upload_to='environmental_review_document/',default='')
    
    # regulatory table
    Regulatory_Concerns_count=models.CharField(max_length=100,blank=False)
    Regulatory_Concerns_mitigation=models.TextField(blank=False)
    Regulatory_Concerns_assigned=models.TextField(blank=False)
    entire_Regulatory_Concerns_doc=models.FileField(upload_to='regulatory_review_document/',default='')
    roc=models.ForeignKey(moc_new, on_delete=models.CASCADE)
    user=models.ForeignKey(standard_user, on_delete=models.CASCADE)
    
    class Meta:
        db_table = "plan_for_change_moc_p_detail"

#approval to implement moc-p
class approval_to_implement_moc_p(models.Model):
    id= models.AutoField(primary_key=True)
    role_user_moc_p=models.CharField(max_length=50,blank=False)
    action_implement_moc_p=models.CharField(max_length=50, blank= False )
    comments_implementation_moc_p=models.TextField(blank= False) 
    Approver_Name_implement_moc_p=models.CharField(max_length=100,blank=False)
    Approver_sign_implement_moc_p=models.CharField(max_length=50, blank=False)
    implement_date_moc_p=models.DateField(auto_now_add=True , blank= False)
    roc=models.ForeignKey(moc_new, on_delete=models.CASCADE)
    user=models.ForeignKey(standard_user, on_delete=models.CASCADE)

    class Meta:
        db_table = "approval_to_implement_moc_p"

    def __str__(self):
        return self.action_implement_moc_p



#verifying moc-p
verify1=(
    ('yes','yes'),
    ('no','no'),
)
verify2=(
    ('yes','yes'),
    ('no','no'),
)
verify3=(
    ('yes','yes'),
    ('no','no'),
)
verify4=(
    ('yes','yes'),
    ('no','no'),
)
verify5=(
    ('yes','yes'),
    ('no','no'),
)

class verification_moc_p(models.Model):
    id= models.AutoField(primary_key=True)
    Basis_verified=models.CharField(max_length=50, choices=verify1 , blank= False, null= True )
    Technical_verified=models.CharField(max_length=50, choices=verify2 , blank= False, null= True )
    hazard_verified=models.CharField(max_length=50, choices=verify3 , blank= False, null= True  )
    env_verified=models.CharField(max_length=50, choices=verify4 , blank= False, null= True  )
    regulatory_verified=models.CharField(max_length=50, choices=verify5 , blank= False, null= True  )
    roc=models.ForeignKey(moc_new, on_delete=models.CASCADE)
    user=models.ForeignKey(standard_user, on_delete=models.CASCADE)
    
    class Meta:
        db_table = "verification_moc_p"

    def __str__(self):
        return self.Basis_verified

#review and closeout moc-p
class review_moc_p(models.Model):
    id= models.AutoField(primary_key=True)
    moc_closure=models.TextField(blank=False)
    effectiveness_review=models.TextField(blank=False)
    reviewer_name=models.CharField(max_length=100, blank= False )
    reviewer_signature=models.CharField(max_length=100, blank= False )
    review_date=models.DateField(auto_now_add=True , blank= False)
    roc=models.ForeignKey(moc_new, on_delete=models.CASCADE)
    user=models.ForeignKey(standard_user, on_delete=models.CASCADE)
    
    class Meta:
        db_table = "review_moc_p"

    def __str__(self):
        return self.moc_closure      