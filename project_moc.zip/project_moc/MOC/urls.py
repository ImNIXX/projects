from django.urls import path
from .import views
from django.conf.urls.static import static
from project_moc import settings

urlpatterns = [
    
    path('', views.index, name="HOME-PAGE"),
    #moc_form
    path('insert-user/', views.moc_user, name="insert-user"),
    # Signup
    path('signup/', views.signup_page, name="signup"),
    path('add-user/', views.insert_user, name="add-user"),
    path('check-username/', views.check_username, name="check-username"),
    # LOGIN
    path('login/', views.login_page, name="login"),
    path('login-user/', views.user_login, name="login-user"),
    # LOGOUT
    path('user-logout/', views.logout, name="user-logout"),
    #approval for plan
    path('roc-action/', views.moc_action, name="roc-action"),
    #plan for changes
    path('roc-plan', views.moc_plan, name="roc-plan"),
    #plan for changes detail
    path('roc-plan-detail', views.moc_plan_detail, name="roc-plan-detail"),
    # GET type of change
    path('get-type-of-change/', views.get_type_of_change, name="get-type-of-change"),
    # GET Title
    path('get-title/', views.get_title, name="get-title"),
    #GET MOC NEW DATA IN FORM
    path('get_moc_new', views.get_moc_new, name="get-moc-new"),
    #approval to implement
    path('roc-implement-action/', views.moc_implement_action, name="roc-implement-action"),
    #verification of moc
    path('roc-verify/', views.moc_verify, name="roc-verify"),
    #review and closure of moc
    path('roc-review/', views.moc_review, name="roc-review"),
    #plan for changes moc-p
    path('roc_p_plan', views.moc_p_plan, name="roc_p_plan"),
    #plan for changes detail moc-p
    path('roc_p_plan_detail', views.moc_p_plan_detail, name="C"),
    #url to get value of consequense selected in plan for change table
    path('get_plan_for_change', views.get_plan_for_change, name="get_plan_for_change"),
     #approval to implement
    path('moc-p-implement-action/', views.moc_P_implement_action, name="moc-p-implement-action"),
    #verification of moc
    path('moc-p-verify/', views.moc_p_verify, name="moc-p-verify"),
    #review and closure of moc
    path('moc-p-review/', views.moc_p_review, name="moc-p-review"),
    #update model moc form 
    path('update-moc-new', views.update_moc_new, name="update-moc-new"),
]
urlpatterns += urlpatterns + static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)

