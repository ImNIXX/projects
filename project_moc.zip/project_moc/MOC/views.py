from django.shortcuts import render,redirect
from MOC.forms import  moc__new_form , FileFieldForm 
from MOC.models import moc_new
from MOC.forms import standard_user_form
from MOC.models import standard_user
from MOC.models import approval_of_plan
from MOC.models import plan_for_change
from MOC.models import plan_for_change_detail
from MOC.models import approval_to_implement
from MOC.models import verification_moc
from MOC.models import review_moc
from MOC.models import plan_for_change_moc_p
from MOC.models import plan_for_change_moc_p_detail
from MOC.models import approval_to_implement_moc_p
from MOC.models import verification_moc_p
from MOC.models import review_moc_p
from django.http import HttpResponse, JsonResponse
from django.contrib import messages
import hashlib
import os
from django.core.mail import send_mail
from django.conf import settings


# Create your views here.
def index(request):
    moc_data = {}
    if 'username' in request.session:
        moc_data['session_username'] = request.session.get('username')
       
        moc_data['session_name'] = request.session.get('name')
        moc_data['session_role'] = request.session.get('role')
        moc_data['session_id'] = request.session.get('user_id')
        moc_data['select_manager'] =standard_user.objects.all().filter(role_id='1')
        moc_data['select_leader'] =standard_user.objects.all().filter(role_id='2')
        moc_data['select_member']=standard_user.objects.all().filter(role_id='3')
        
        # print(moc_data['select_member'])
        # moc_data['plan_consequense'] = plan_for_change.objects.all().filter(plan_consequense='plan')
           
        if moc_data['session_role'] == 0:
            moc_data['select_user']=moc_new.objects.all().filter(user_id=moc_data['session_id'])
            moc_data['data_approval']=approval_of_plan.objects.all().filter(user_id=moc_data['session_id'])
            
            # moc_data['object']=approval_of_plan.objects.all()
            # print( moc_data['object'])
        if moc_data['session_role'] == 1:
            moc_data['select_user']=moc_new.objects.all().filter(select_manager=moc_data['session_username'])
            moc_data['data_approval']=approval_of_plan.objects.all()
            moc_data['data_implement']=approval_to_implement.objects.all()
            # moc_new.objects.filter(id=1).delete()
            # moc_data['abc']=approval_of_plan.objects.all().filter(roc_id=moc_data['session_username'])
            # print(moc_data['data_implement'])
            
               

        if moc_data['session_role']==2:
            # moc_data['select_user']=moc_new.objects.all().filter(select_manager=moc_data['session_username'])
            moc_data['select_user']=moc_new.objects.all().filter(approval_of_plan__select_leader=moc_data['session_username'])
            moc_data['data_approval']=approval_of_plan.objects.all().filter(select_member=moc_data['session_username'])
            # moc_data['data_consequense']= plan_for_change.objects.all().filter(plan_consequense=moc_data['plan_consequense'])
            # print( moc_data['data_approval'])
                
        if moc_data['session_role']==3:
            moc_data['select_user']=moc_new.objects.all().filter(approval_of_plan__select_member__contains=moc_data['session_username'])
            # moc_data['data_approval']=approval_of_plan.objects.all().filter(select_member=moc_data['session_username'])
            moc_data['data_approval']=approval_of_plan.objects.filter(select_member__contains=moc_data['session_username'])
            # moc_data['roc_leader'] = moc_new.objects.filter(approval_of_plan__select_leader='nikhilesh@123')
            # print(moc_data['select_user'])
            # moc_data['abc'] = moc_new.objects.filter(approval_of_plan__select_leader__contains='nikhilesh@123')
           
            
    else:
        moc_data['session_username'] = ''
        return redirect('login')
# Render the HTML template index.html
    return render(request, 'index.html',moc_data)




def moc_user(request):
    if request.method == "POST":
            post=moc_new()
            post.title= request.POST.get('title')
            post.name= request.POST.get('name')
            post.date= request.POST.get('date')
            post.type_of_change= request.POST.get('type_of_change')
            post.businessfile=request.FILES.get('businessfile')
            # post.businessfile = request.FILES.popitem()  # get first element of the uploaded files

        # file = file[0]
           
            post.changeduration= request.POST.get('chngeduration')
            post.months= request.POST.get('months', None)
            post.Proposal_changes= request.POST.get('Proposal_changes')
            post.business_case= request.POST.get('business_case')
            post.Datestart= request.POST.get('Datestart')
            post.Dateend= request.POST.get('Dateend')
            post.implications= request.POST.get('implications')
            post.Estimate= request.POST.get('Estimate')
            post.select_manager=request.POST.get('select_manager')
            post.user_id=request.session.get('user_id')
            # post.status=request.session.get('status')
            
            post.save()
            
        
            messages.success(request, 'Request of change sumitted sucessfully.')
            return redirect('HOME-PAGE')
        
    else:
        
        return redirect('HOME-PAGE')



# # LOGIN


def login_page(request):
        if request.session.get('user_id'):
           response = redirect('HOME-PAGE')
           return response
        return render(request, 'login.html')


def user_login(request):
         username1 = request.POST.get('username', None)
         password1 = request.POST.get('password', None)
         username_data = standard_user.objects.filter(username=username1)
         if username_data:
            result = hashlib.md5(password1.encode())
            password1 = result.hexdigest()
            password_data = standard_user.objects.filter(username=username1, password=password1)
            if password_data:
                 password_data = standard_user.objects.get(username=username1, password=password1)
                 request.session['user_id'] = password_data.id
                 request.session['username'] = password_data.username
                 request.session['name'] = password_data.name
                 request.session['email'] = password_data.email
            
                 request.session['role'] = password_data.role_id
                 return redirect('HOME-PAGE')
            else:
                 messages.warning(request, 'Password is not correct')
                 response = redirect('login')
                 return response
         else:
             messages.warning(request, 'Username is not correct')
             response = redirect('login')
             return response


 #END LOGIN
# LOGOUT

def logout(request):
    if request.session.get('user_id'):
        del request.session['user_id']
        del request.session['username']
        del request.session['email']
        del request.session['role']
        
        response = redirect('login')
        return response
    else:
        response = redirect('HOME-PAGE')
        return response


# END LOGOUT
# SIGNUP


def signup_page(request):
    if request.session.get('user_id'):
        response = redirect('HOME-PAGE')
        
        return response
    return render(request,'signup.html')


def check_username(request):
    username = request.POST.get('username', None)
    username_data = standard_user.objects.filter(username=username)
    if username_data:
        username_exist = 'exist'
    else:
        username_exist = 'not exist'
    return HttpResponse(username_exist)


def insert_user(request):
    
    username = request.POST.get('username', None)
    name = request.POST.get('name', None)
    email = request.POST.get('email', None)
    password = request.POST.get('password', None)
    pass_result = hashlib.md5(password.encode())
    password = pass_result.hexdigest()
    contact=request.POST.get('contact', None)
    zipcode = request.POST.get('zipcode', None)
    user_add = standard_user(name=name, username=username, email=email, password=password,contact=contact, zipcode=zipcode, role_id='0', status='1' )
    user_add.save()
    send_mail('My Subject', 'Registered sucessfuly','anshulbhargava@ymail.com',
    [email], fail_silently=False)
    
    if user_add.id:
        request.session['user_id'] = user_add.id
        request.session['username'] = user_add.username
        request.session['email'] = user_add.email
        request.session['role'] = user_add.role_id
        response = redirect('HOME-PAGE')
        return response
    else:
        response = redirect('signup')
        return response


# END SIGNUP

# APPROVAL OF PLAN
 
def moc_action(request):
    if request.method == "POST":
        
        post=approval_of_plan()
        
        post.action_roc= request.POST.get('action_roc')
        post.reason_roc= request.POST.get('reason_roc')
        post.approver_name= request.POST.get('approver_name')
        post.sign_roc= request.POST.get('sign_roc')
        post.date_roc= request.POST.get('date_roc')
        post.select_leader= request.POST.get('select_leader')
        post.select_member= request.POST.getlist('select_member')
        post.roc_id=request.POST.get('roc_id')
        roc_data = moc_new.objects.get(id=request.POST.get('roc_id'))
        post.user_id=roc_data.user_id
        post.save()
        if post.action_roc =='Approved for plan':
            moc_new.objects.filter(id=post.roc_id).update(status=1)
            moc_new.objects.filter(id=post.roc_id).update(status_of_form=1)
        elif post.action_roc =='Rejected':
            moc_new.objects.filter(id=post.roc_id).update(status=2)
        elif post.action_roc =='Postpone':
            moc_new.objects.filter(id=post.roc_id).update(status=3)
        elif post.action_roc =='Cancel':
            moc_new.objects.filter(id=post.roc_id).update(status=4) 
       
                  
        email=standard_user.objects.filter(id=roc_data.user_id).values_list('email', flat=True)
        title=moc_new.objects.filter(id=post.roc_id).values_list('title',flat=True)
        name=moc_new.objects.filter(id=post.roc_id).values_list('name',flat=True)
        str1 = post.action_roc + ", " + title[0]+"," + name[0]
        send_mail('Action on ROC',str1,'anshulbhargava@ymail.com', email, fail_silently=False)
        return redirect('HOME-PAGE')
        
    else:
        return redirect('HOME-PAGE')

# END APPROVAL OF PLAN

# plan of change start
def moc_plan(request):
    if request.method == "POST":
        # print(request.POST.getlist('plan_consequense'))
        post=plan_for_change()
        post.roc_id=request.POST.get('roc_id')
        roc_data = moc_new.objects.get(id=post.roc_id)
        post.user_id=roc_data.user_id
        post.plan_consequense=request.POST.getlist('plan_consequense')
        post.plan_stakeholders=request.POST.get('plan_stakeholders')
        post.stakeholders_document=request.FILES.get('stakeholders_document')
        post.plan_Processes=request.POST.get('plan_Processes')
        post.Processes_document=request.FILES.get('Processes_document')
        post.plan_information=request.POST.get('plan_information')   
        post.information_document=request.FILES.get('information_document')
        post.plan_training=request.POST.get('plan_training')
        post.training_document=request.FILES.get('training_document')
        
        post.save()
        moc_new.objects.filter(id=post.roc_id).update(status_of_form=2)
        return HttpResponse("save")
    else:
        return HttpResponse('HOME-PAGE')



def get_type_of_change(request):
    roc_id = request.POST.get('roc_id')
    type_of_change = moc_new.objects.get(id=roc_id)
  
    return HttpResponse(type_of_change.type_of_change)

def get_title(request):
    roc_id = request.POST.get('roc_id')
    id = moc_new.objects.get(id=roc_id)
   
    return HttpResponse(id.id)

   
    

def get_moc_new(request):
    id= request.POST.get('id')
    moc_data_roc=moc_new.objects.get(id=id)
    res_data = {'id':moc_data_roc.id,'title':moc_data_roc.title, 'name': moc_data_roc.name, 'date': moc_data_roc.date,'type_of_change':moc_data_roc.type_of_change,'changeduration':moc_data_roc.changeduration,'months':moc_data_roc.months,'Proposal_changes':moc_data_roc.Proposal_changes,'business_case':moc_data_roc.business_case,'Datestart':moc_data_roc.Datestart,'Dateend':moc_data_roc.Dateend,'implications':moc_data_roc.implications,'Estimate':moc_data_roc.Estimate,'select_manager':moc_data_roc.select_manager}

    return JsonResponse(res_data)


def handle_uploaded_file(f, dir_name):
    draft_dir = os.getcwd()
    destination = open(settings.MEDIA_ROOT+'/'+dir_name+'/' + f.name, 'wb+')
    for chunk in f.chunks():
        destination.write(chunk)
    destination.close()
    

    
    
def moc_plan_detail(request):
    if request.method == "POST":
        
        post=plan_for_change_detail()
        post.type_consequense=request.POST.getlist('type_consequense[]')
        post.mitigation_consequense=request.POST.getlist('mitigation_consequense[]')
        post.consequences_doc=request.FILES.get('consequences_doc')

        post.group_stakeholder=request.POST.getlist('group_stakeholder[]')
        post.reason_of_impact=request.POST.getlist('reason_of_impact[]')
        post.proposed_mitigation=request.POST.getlist('proposed_mitigation[]')

        post.entire_stakeholdertext_doc=request.FILES.get('entire_stakeholdertext_doc')
        post.additional_study=request.POST.getlist('additional_study')   

        
        post.type_procedure=request.POST.getlist('type_procedure[]')
        procedure_doc = []
        for uploaded_file in request.FILES.getlist('procedure_doc'):
            procedure_doc.append(uploaded_file.name)
            handle_uploaded_file(uploaded_file, 'Processes_document')
        post.procedure_doc=procedure_doc
        

        
        post.procedure_update=request.POST.getlist('procedure_update[]')
        post.procedure_assigned=request.POST.getlist('procedure_assigned[]')
        post.entire_procedure_doc=request.FILES.get('entire_procedure_doc')

        post.type_document=request.POST.getlist('type_document[]')
        document_doc = []
        for uploaded_file in request.FILES.getlist('document_doc'):
            document_doc.append(uploaded_file.name)
            handle_uploaded_file(uploaded_file, 'information_document')
        post.document_doc=document_doc
        post.document_update=request.POST.getlist('document_update[]')
        post.document_assigned=request.POST.getlist('document_assigned[]')
        post.entire_document_doc=request.FILES.get('entire_document_doc')
        
        post.type_training=request.POST.getlist('type_training[]')
        training_doc = []
        for uploaded_file in request.FILES.getlist('training_doc'):
            training_doc.append(uploaded_file.name)
            handle_uploaded_file(uploaded_file, 'training_document')
        post.training_doc=training_doc
        post.training_update=request.POST.getlist('training_update[]')
        post.training_assigned=request.POST.getlist('training_assigned[]')
        post.entire_training_doc=request.FILES.get('entire_training_doc')

        post.inspection_require=request.POST.get('inspection_require')
        post.pha_require=request.POST.get('pha_require')
        post.roc_id=request.POST.get('roc_id')
        roc_data = moc_new.objects.get(id=post.roc_id)
        post.user_id=roc_data.user_id

        post.save()
        moc_new.objects.filter(id=post.roc_id).update(status_of_form=3)
        # return HttpResponse(request.FILES.getlist('training_doc'))
        # return HttpResponse('HELLO')
        return redirect('HOME-PAGE')
    else:
        # return HttpResponse('asd')
        return redirect('HOME-PAGE')



def moc_implement_action(request):
    if request.method == "POST":
        
        post=approval_to_implement()
        post.role_user=request.POST.get('role_user')
        post.action_implement_roc= request.POST.get('action_implement_roc')
        post.comments_implementation= request.POST.get('comments_implementation')
        post.Approver_Name_implement= request.POST.get('Approver_Name_implement')
        post.Approver_sign_implement= request.POST.get('Approver_sign_implement')
        post.implement_date= request.POST.get('implement_date')
        post.roc_id=request.POST.get('roc_id')
        roc_data = moc_new.objects.get(id=post.roc_id)
        post.user_id=roc_data.user_id
        post.save()
        if post.action_implement_roc =='Approved to implement':
            moc_new.objects.filter(id=post.roc_id).update(status_implement=1)
            moc_new.objects.filter(id=post.roc_id).update(status_of_form=4)
        elif post.action_implement_roc =='Rejected':
            moc_new.objects.filter(id=post.roc_id).update(status_implement=2)
        elif post.action_implement_roc =='Postpone':
            moc_new.objects.filter(id=post.roc_id).update(status_implement=3)
        elif post.action_implement_roc =='Cancel':
            moc_new.objects.filter(id=post.roc_id).update(status_implement=4)           
        email=standard_user.objects.filter(id=roc_data.user_id).values_list('email', flat=True)
        title=moc_new.objects.filter(id=post.roc_id).values_list('title',flat=True)
        name=moc_new.objects.filter(id=post.roc_id).values_list('name',flat=True)
        str1 = post.action_implement_roc + ", " + title[0]+"," + name[0]
        send_mail('Action on ROC',str1,'anshulbhargava@ymail.com', email, fail_silently=False)
        return redirect('HOME-PAGE')
        
    else:
        return redirect('HOME-PAGE') 




def moc_verify(request):
    if request.method == "POST":
        
        post=verification_moc()
        
        post.training_verified= request.POST.get('training_verified')
        post.procedures_verified= request.POST.get('procedures_verified')
        post.documentation_verified= request.POST.get('documentation_verified')
        post.other_action= request.POST.get('other_action')
        post.roc_id=request.POST.get('roc_id')
        roc_data = moc_new.objects.get(id=post.roc_id)
        post.user_id=roc_data.user_id
        post.save()
        if post.training_verified == 'yes' and post.procedures_verified == 'yes' and post.documentation_verified == 'yes' and post.other_action == 'yes':
            moc_new.objects.filter(id=post.roc_id).update(status_of_form=6)        
            email=standard_user.objects.filter(id=roc_data.user_id).values_list('email', flat=True)
            title=moc_new.objects.filter(id=post.roc_id).values_list('title',flat=True)
            name=moc_new.objects.filter(id=post.roc_id).values_list('name',flat=True)
            str1 = 'Verified' + ", " + title[0]+"," + name[0]
            send_mail('Action on ROC',str1,'anshulbhargava@ymail.com', email, fail_silently=False)
        return redirect('HOME-PAGE')
        
    else:
        return redirect('HOME-PAGE')   


def moc_review(request):
    if request.method == "POST":
        
        post=review_moc()
        
        post.moc_closure= request.POST.get('moc_closure')
        post.effectiveness_review= request.POST.get('effectiveness_review')
        post.reviewer_name= request.POST.get('reviewer_name')
        post.reviewer_signature= request.POST.get('reviewer_signature')
        post.review_date= request.POST.get('review_date')
        post.roc_id=request.POST.get('roc_id')
        roc_data = moc_new.objects.get(id=post.roc_id)
        post.user_id=roc_data.user_id
        post.save()
        moc_new.objects.filter(id=post.roc_id).update(status_of_form=7) 
        
        return redirect('HOME-PAGE')
        
    else:
        return redirect('HOME-PAGE')  


def moc_p_plan(request):
    if request.method == "POST":
        # print(request.POST.getlist('plan_consequense'))
        post=plan_for_change_moc_p()
        post.roc_id=request.POST.get('roc_id')
        roc_data = moc_new.objects.get(id=post.roc_id)
        post.user_id=roc_data.user_id
        post.basis_for_change=request.POST.getlist('basis_for_change')
        post.technical_review=request.POST.get('technical_review')
        post.technical_review_document=request.FILES.get('technical_review_document')
        post.risk_review=request.POST.get('risk_review')
        post.risk_review_document=request.FILES.get('risk_review_document')
        post.environmental_review=request.POST.get('environmental_review')   
        post.environmental_review_document=request.FILES.get('environmental_review_document')
        post.regulatory_review=request.POST.get('regulatory_review')
        post.regulatory_review_document=request.FILES.get('regulatory_review_document')
        
        post.save()
        moc_new.objects.filter(id=post.roc_id).update(status_of_form=2)
        return HttpResponse("save")
    else:
        return HttpResponse('HOME-PAGE')
#plan detail moc-p
def moc_p_plan_detail(request):
    if request.method == "POST":
        
        post=plan_for_change_moc_p_detail()
        post.type_moc_p_consequense=request.POST.getlist('type_moc_p_consequense[]')
        post.mitigation_moc_p_consequense=request.POST.getlist('mitigation_moc_p_consequense[]')
        post.moc_p_consequences_doc=request.FILES.get('moc_p_consequences_doc')

        post.Technical_Impact_count=request.POST.getlist('Technical_Impact_count[]')
        post.reason_of_impact=request.POST.getlist('reason_of_impact[]')
        post.proposed_mitigation_impact=request.POST.getlist('proposed_mitigation_impact[]')
        post.entire_technical_doc=request.FILES.get('entire_technical_doc')
        
        post.technical_risks_impact=request.POST.getlist('technical_risks_impact[]')
        post.technical_risks_impact_mitigation=request.POST.getlist('technical_risks_impact_mitigation[]')
        post.technical_risks_impact_doc=request.FILES.get('technical_risks_impact_doc')

        post.financial_impact=request.POST.getlist('finacial_impact[]')
        post.financial_impact_mitigation=request.POST.getlist('financial_impact_mitigation[]')
        post.financial_impact_doc=request.FILES.get('financial_impact_doc')

        post.stratagic_impact=request.POST.getlist('stratagic_impact[]')
        post.stratagic_impact_mitigation=request.POST.getlist('stratagic_impact_mitigation[]')
        post.stratagic_impact_doc=request.FILES.get('stratagic_impact_doc')

        post.assesment_impact=request.POST.getlist('assesment_impact[]')
        post.assesment_impact_mitigation=request.POST.getlist('assesment_impact_mitigation[]')
        post.assesment_impact_doc=request.FILES.get('assesment_impact_doc')
        
        post.additional_study=request.POST.getlist('additional_study')   

        
        #hazard table
        

        post.Risk_count=request.POST.getlist('Risk_count[]')
        post.Risk_count_mitigation=request.POST.getlist('Risk_count_mitigation[]')
        post.Risk_count_assigned=request.POST.getlist('Risk_count_assigned[]')
        post.entire_Risk_doc=request.FILES.get('entire_Risk_doc')

        #environment table
        post.Environmental_Impact_count=request.POST.getlist('Environmental_Impact_count[]')
        post.Environmental_Impact_mitigation=request.POST.getlist('Environmental_Impact_mitigation[]')
        post.Environmental_Impact_assigned=request.POST.getlist('Environmental_Impact_assigned[]')
        post.entire_Environmental_Impact_doc=request.FILES.get('entire_Environmental_Impact_doc')


        #regulatory table
        post.Regulatory_Concerns_count=request.POST.getlist('Regulatory_Concerns_count[]')
        post.Regulatory_Concerns_mitigation=request.POST.getlist('Regulatory_Concerns_mitigation[]')
        post.Regulatory_Concerns_assigned=request.POST.getlist('Regulatory_Concerns_assigned[]')
        post.entire_Regulatory_Concerns_doc=request.FILES.get('entire_Regulatory_Concerns_doc')

        post.roc_id=request.POST.get('roc_id')
        roc_data = moc_new.objects.get(id=post.roc_id)
        post.user_id=roc_data.user_id
        post.save()
        moc_new.objects.filter(id=post.roc_id).update(status_of_form=3)
        
        return redirect('HOME-PAGE')
    else:

        return redirect('HOME-PAGE')

#function to get value of consequense selected in plan for change table
def get_plan_for_change(request):
    roc_id = request.POST.get('roc_id', None)
    type = request.POST.get('type', None)
    if (type !='Personnel'):
        data_moc=plan_for_change.objects.get(roc_id=roc_id)
        data = data_moc.plan_consequense
    else:
        data_moc=plan_for_change_moc_p.objects.get(roc_id=roc_id)
        data = data_moc.basis_for_change
    data = eval(data)
    data_val = data[0].split(",")
    data_response = {}
    for i in data_val:
        data_response[i] = i
    # print(data)
    return JsonResponse(data_response)

#approval to implement MOC-P
def moc_P_implement_action(request):
    if request.method == "POST":
        
        post=approval_to_implement_moc_p()
        post.role_user_moc_p=request.POST.get('role_user_moc_p')
        post.action_implement_moc_p= request.POST.get('action_implement_moc_p')
        post.comments_implementation_moc_p= request.POST.get('comments_implementation_moc_p')
        post.Approver_Name_implement_moc_p= request.POST.get('Approver_Name_implement_moc_p')
        post.Approver_sign_implement_moc_p= request.POST.get('Approver_sign_implement_moc_p')
        post.implement_date_moc_p= request.POST.get('implement_date_moc_p')
        post.roc_id=request.POST.get('roc_id')
        roc_data = moc_new.objects.get(id=post.roc_id)
        post.user_id=roc_data.user_id
        post.save()
        if post.action_implement_moc_p =='Approved to implement':
            moc_new.objects.filter(id=post.roc_id).update(status_implement=1)
            moc_new.objects.filter(id=post.roc_id).update(status_of_form=4)
        elif post.action_implement_moc_p =='Rejected':
            moc_new.objects.filter(id=post.roc_id).update(status_implement=2)
        elif post.action_implement_moc_p =='Postpone':
            moc_new.objects.filter(id=post.roc_id).update(status_implement=3)
        elif post.action_implement_moc_p =='Cancel':
            moc_new.objects.filter(id=post.roc_id).update(status_implement=4)           
        email=standard_user.objects.filter(id=roc_data.user_id).values_list('email', flat=True)
        title=moc_new.objects.filter(id=post.roc_id).values_list('title',flat=True)
        name=moc_new.objects.filter(id=post.roc_id).values_list('name',flat=True)
        str1 = post.action_implement_moc_p + ", " + title[0]+"," + name[0]
        send_mail('Action on ROC',str1,'anshulbhargava@ymail.com', email, fail_silently=False)
        return redirect('HOME-PAGE')
        
    else:
        return redirect('HOME-PAGE') 

def moc_p_verify(request):
    if request.method == "POST":
        
        post=verification_moc_p()
        
        post.Basis_verified= request.POST.get('Basis_verified')
        post.Technical_verified= request.POST.get('Technical_verified')
        post.hazard_verified= request.POST.get('hazard_verified')
        post.env_verified= request.POST.get('env_verified')
        post.regulatory_verified= request.POST.get('regulatory_verified')
        post.roc_id=request.POST.get('roc_id')
        roc_data = moc_new.objects.get(id=post.roc_id)
        post.user_id=roc_data.user_id
        post.save()
        if post.Basis_verified == 'yes' and post.Technical_verified == 'yes' and post.hazard_verified == 'yes' and post.env_verified == 'yes' and post.regulatory_verified == 'yes':
            moc_new.objects.filter(id=post.roc_id).update(status_of_form=5)        
            email=standard_user.objects.filter(id=roc_data.user_id).values_list('email', flat=True)
            title=moc_new.objects.filter(id=post.roc_id).values_list('title',flat=True)
            name=moc_new.objects.filter(id=post.roc_id).values_list('name',flat=True)
            str1 = 'Verified' + ", " + title[0]+"," + name[0]
            send_mail('Action on ROC',str1,'anshulbhargava@ymail.com', email, fail_silently=False)
        return redirect('HOME-PAGE')
        
    else:
        return redirect('HOME-PAGE')   


def moc_p_review(request):
    if request.method == "POST":
        
        post=review_moc_p()
        
        post.moc_closure= request.POST.get('moc_closure')
        post.effectiveness_review= request.POST.get('effectiveness_review')
        post.reviewer_name= request.POST.get('reviewer_name')
        post.reviewer_signature= request.POST.get('reviewer_signature')
        post.review_date= request.POST.get('review_date')
        post.roc_id=request.POST.get('roc_id')
        roc_data = moc_new.objects.get(id=post.roc_id)
        post.user_id=roc_data.user_id
        post.save()
        moc_new.objects.filter(id=post.roc_id).update(status_of_form=7) 
        
        return redirect('HOME-PAGE')
        
    else:
        return redirect('HOME-PAGE')        




def update_moc_new(request):
    id = request.POST.get('id', None)
    title= request.POST.get('title')
    name= request.POST.get('name')
    date= request.POST.get('date')
    type_of_change= request.POST.get('type_of_change')
    businessfile=request.FILES.get('businessfile')
    changeduration= request.POST.get('chngeduration')
    months= request.POST.get('months', None)
    Proposal_changes= request.POST.get('Proposal_changes')
    business_case= request.POST.get('business_case')
    Datestart= request.POST.get('Datestart')
    Dateend= request.POST.get('Dateend')
    implications= request.POST.get('implications')
    Estimate= request.POST.get('Estimate')
    select_manager=request.POST.get('select_manager')
   
    # GET INSPECTION
    # moc_data = Inspections.objects.get(id=inspection_id)if ins_data.type == inspection_type:

    update_data = moc_new.objects.filter(id=id).update(title=title, name=name, date=date, type_of_change=type_of_change, businessfile=businessfile, changeduration=changeduration, months=months, Proposal_changes=Proposal_changes,business_case=business_case,Datestart=Datestart,Dateend=Dateend,implications=implications,Estimate=Estimate,select_manager=select_manager)
    if update_data:
        return redirect('HOME-PAGE')
    else:
        return redirect('HOME-PAGE') 
           
    