-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 02, 2020 at 08:32 AM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.4.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `se_moc`
--

-- --------------------------------------------------------

--
-- Table structure for table `moc_user`
--

CREATE TABLE `moc_user` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `contact` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `image` varchar(100) NOT NULL,
  `zipcode` varchar(100) NOT NULL,
  `dob` varchar(100) NOT NULL,
  `role_id` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `register_date` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `moc_user`
--

INSERT INTO `moc_user` (`id`, `username`, `name`, `email`, `password`, `contact`, `address`, `image`, `zipcode`, `dob`, `role_id`, `status`, `register_date`) VALUES
(1, 'anshul@123', 'anshul', 'anshatnoida@gmail.com', '052a5f42af6fec12598a43da02bed43b', '', '', '', '302020', '', 0, 1, '2020-09-23 17:28:16.571175'),
(2, 'amit@123', 'amit sharma', 'amits@gmail.com', '62aff5e676a5c89f4203ecd2ae6478c8', '9876543201', 'jaipur', 'as', '302020', '27/02/1984', 1, 1, '2020-09-23 17:34:26.385666'),
(3, 'gaurav@123', 'gaurav sharma', 'gauravsharmaa3@gmail.com', '857f12c7851f6931f1c1ea871cce12e2', '', '', '', '302020', '', 0, 1, '2020-09-24 11:39:33.768458'),
(4, 'atul@123', 'Atul', 'atul@gmail.com', '9763d3de0df49d64fcba1835d7457ce1', '9876543201', 'jaipur', 'as', '302019', '27/02/1991', 1, 1, '2020-09-24 11:43:03.887553'),
(5, 'nikhilesh@123', 'nikhilesh', 'nikhilesh@gmail.com', '9e5e1399211e65065d55310a69286922', '9876543201', 'jaipur', 'as', '302020', '27/02/1991', 2, 1, '2020-09-24 12:40:10.273584'),
(6, 'puru@123', 'puru', 'puru@gmail.com', 'ba82c469925c9c3931d49f4a19ed501c', '9876543201', 'jaipur', 'as', '302019', '27/02/1991', 2, 1, '2020-09-30 08:52:52.736337'),
(7, 'rahul@123', 'Rahul', 'anshulbhargava@ymail.com', 'ebaaba27b32928a25f2ad6185fc0cc74', '', '', '', '302019', '', 0, 1, '2020-09-30 10:20:36.363075'),
(9, 'mohit@123', 'mohit', 'mohit@gmail.com', '48418969a4071bf494272463b4e6b324', '9876543201', '', '', '302020', '', 0, 1, '2020-09-30 10:33:26.641167'),
(10, 'jack@123', 'jack', 'jack@gmail.com', '12ef7c5f50528bb5a002033ffa5551ee', 'jack@123', 'jaipur', 'as', '302019', '27/02/1991', 3, 1, '2020-10-01 05:00:42.983613'),
(11, 'michael', 'Michael', 'michael@gmail.com', '92d1721dc8662fdf8b8b7f2a19045426', '987654321', 'jaipur', 'as', '302019', '27/02/1991', 3, 1, '2020-10-01 05:00:42.983613');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `moc_user`
--
ALTER TABLE `moc_user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `moc_user`
--
ALTER TABLE `moc_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
