from django.http import HttpResponse
from django.shortcuts import render

def index(request):
    params = {'name':'NIXX'}
    return render(request, 'index.html', params)
    # return HttpResponse('Hello')


def about(request):
    return HttpResponse('Hello NIXX')


def submit_page(request):
    get_data = request.POST.get('name', 'default')
    return HttpResponse(get_data)

