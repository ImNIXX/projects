from django.apps import AppConfig


class AgSafeAppConfig(AppConfig):
    name = 'ag_safe_app'
