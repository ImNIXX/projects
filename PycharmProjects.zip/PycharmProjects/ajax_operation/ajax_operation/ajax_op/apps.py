from django.apps import AppConfig


class AjaxOpConfig(AppConfig):
    name = 'ajax_op'
