from django.apps import AppConfig


class InspConfig(AppConfig):
    name = 'insp'
