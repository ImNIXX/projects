from django.shortcuts import render

# Create your views here.


def employee_register(request):
    return render(request, '')


def employee_list(request):
    return

def employee_delete(request):
    return