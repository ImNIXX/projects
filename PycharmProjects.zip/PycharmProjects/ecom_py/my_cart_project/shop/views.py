from django.http import HttpResponse
from django.shortcuts import render
from .models import Product,Contact
# Create your views here.

def index(request):
    products = Product.objects.all()

    dict = {'data':products}


    return  render(request,'shop/index.html',dict)

def about(request):
    return  render(request,'shop/about.html')

def contact(request):
    if(request.method == "POST"):
        name = request.POST.get('name','')
        email = request.POST.get('email','')
        subject = request.POST.get('subject','')
        msg = request.POST.get('msg','')
        info = Contact(name=name,email=email,subject=subject,msg=msg)
        info.save()
    return render(request,'shop/contact.html')

def checkout(request):
    return render(request,'shop/checkout.html')

def tracker(request):
    return render(request, 'shop/tracker.html')

def search(request):
    return HttpResponse('search')

def detail_page(request):
    return HttpResponse('about')

def single_page(request,myid):
    product = Product.objects.filter(id=myid)
    print('sdf')
    print(product)
    return render(request,'shop/single.html',{'product':product[0]})