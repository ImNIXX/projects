from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name="CartHome"),
    path('about', views.about, name="aboutUs"),
    path('contact', views.contact, name="contactUs"),
    path('tracker', views.tracker, name="trackerItem"),
    path('search', views.search, name="searchItem"),
    path('detail_page', views.detail_page, name="detailItem_page"),
    path('checkout', views.checkout, name="checkout_page"),
    path('single_item/<int:myid>', views.single_page, name="singleItem_page"),
]