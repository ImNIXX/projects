from django.apps import AppConfig


class CrudOperationsConfig(AppConfig):
    name = 'crud_operations'
