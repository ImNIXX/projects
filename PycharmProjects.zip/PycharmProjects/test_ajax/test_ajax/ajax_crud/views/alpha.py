from django.http import HttpResponse
from django.template.loader import get_template
from ..utils import render_to_pdf
from django.views.generic import View


class View_a(View):
    def get(self, request, *args, **kwargs):
        # getting the template
        template = get_template('abc/test.html')
        # rendering the template
        context = {
            "invoice_id": 123,
            "customer_name": "John Cooper",
            "amount": 1399.99,
            "today": "Today",
        }
        html = template.render(context)
        pdf = render_to_pdf('abc/test.html', context)
        if pdf:
            response = HttpResponse(pdf, content_type='application/pdf')
            filename = "Invoice_%s.pdf" % ("12341231")
            content = "inline; filename='%s'" % (filename)
            download = request.GET.get("download")
            if download:
                content = "attachment; filename='%s'" % (filename)
            response['Content-Disposition'] = content
            return response
        return HttpResponse("Not found")



def view_b(request):
    return HttpResponse('view_b page')
