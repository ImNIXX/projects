from django.apps import AppConfig


class AjaxCrudConfig(AppConfig):
    name = 'ajax_crud'
