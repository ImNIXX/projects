from django.urls import path, include
from . import views
from .views import View_a

urlpatterns = [
    path('view-a/',  View_a.as_view()),
    path('view-c/',  views.view_c, name="view_c"),
]