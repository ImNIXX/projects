from django.contrib import admin
from .models import moc_new, standard_user,approval_of_plan,plan_for_change,plan_for_change_detail

# Register your models here.
admin.site.register(moc_new)
admin.site.register(standard_user)
admin.site.register(approval_of_plan)
admin.site.register(plan_for_change)
admin.site.register(plan_for_change_detail)
