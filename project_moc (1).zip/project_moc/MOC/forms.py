from django import forms  
from MOC.models import moc_new 
from MOC.models import standard_user
class moc__new_form(forms.ModelForm):  
    class Meta:  
        model = moc_new  
        fields = "__all__"




class standard_user_form(forms.ModelForm):
    class Meta:
        model = standard_user
        fields = "__all__"

class FileFieldForm(forms.Form):
    file_field = forms.FileField(widget=forms.ClearableFileInput(attrs={'multiple': True}))