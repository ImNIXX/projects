from django.apps import AppConfig


class MocConfig(AppConfig):
    name = 'MOC'
