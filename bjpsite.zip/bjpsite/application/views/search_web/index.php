<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<input type="text" class="search_val">
	<button class="search">Search</button>
	<br><br>
	<div class="html_block">
		<table width="700" border="0" align="center" cellpadding="0" cellspacing="0">
  <tbody><tr>
    <td>      <div align="left">
      <p><strong>Rule 7. Rate of tax of the composition levy.- </strong></p>
      <p align="justify" 1"="">The category of registered persons, eligible for composition levy under <a href="AC136.htm" class="testClick" 14"="">section 10</a>  and the provisions of this Chapter, specified in column (2) of the Table below shall pay tax under <a href="AC136.htm" class="testClick" 14"="">section 10</a>  at the rate specified in column (3) of the said Table:-</p>
      <p align="center" 1"=""><strong><span 12="" style13="" style10"=""><strong><sup>1</sup></strong></span>[Table</strong></p>
      <table width="700" height="0" border="1" align="center" cellpadding="0" cellspacing="0">
        <tbody>
          <tr>
            <td width="28" valign="top"><p align="center"><strong>Sl. No.</strong></p></td>
            <td width="128" valign="top"><p align="center"><strong>Section under which composition levy is opted</strong></p></td>
            <td width="293" valign="top"><p align="center"><strong>Category of registered persons</strong></p></td>
            <td width="241" valign="top"><p align="center"><strong>Rate of tax</strong></p></td>
          </tr>
          <tr>
            <td valign="top"><p align="center"><strong>(1)</strong></p></td>
            <td valign="top"><p align="center"><strong>(1A)</strong></p></td>
            <td valign="top"><p align="center"><strong>(2)</strong></p></td>
            <td valign="top"><p align="center"><strong>(3)</strong></p></td>
          </tr>
          <tr>
            <td valign="top"><p align="center">1.</p></td>
            <td valign="top"><p align="justify" 1"="">Sub-sections (1) and (2) of <a href="AC136.htm" class="testClick" 14"="">section 10</a> </p></td>
            <td valign="top"><p align="justify" 1"="">Manufacturers, other than manufacturers of such goods as may be notified by the Government </p></td>
            <td valign="top"><p align="justify" 1"="">half per cent. of the turnover in the State or Union territory </p></td>
          </tr>
          <tr>
            <td valign="top"><p align="center">2.</p></td>
            <td valign="top"><p align="justify" 1"="">Sub-sections (1) and (2) of <a href="AC136.htm" class="testClick" 14"="">section 10</a> </p></td>
            <td valign="top"><p align="justify" 1"="">Suppliers making supplies referred to in clause (b) of paragraph 6 of <a href="AC309.htm" class="testClick" 14"="">Schedule II</a></p></td>
            <td valign="top"><p align="justify" 1"="">two and a half per cent. of the turnover in the State or Union territory </p></td>
          </tr>
          <tr>
            <td valign="top"><p align="center">3.</p></td>
            <td valign="top"><p align="justify" 1"="">Sub-sections (1) and (2) of <a href="AC136.htm" class="testClick" 14"="">section 10</a> </p></td>
            <td valign="top"><p align="justify" 1"="">Any other supplier eligible for composition levy under sub-sections (1) and (2) of <a href="AC136.htm" class="testClick" 14"="">section 10</a> </p></td>
            <td valign="top"><p align="justify" 1"="">half per cent. of the turnover of taxable supplies of goods and services in the State or Union territory </p></td>
          </tr>
          <tr>
            <td valign="top"><p align="center">4.</p></td>
            <td valign="top"><p align="justify" 1"="">Sub-section (2A) of <a href="AC136.htm" class="testClick" 14"="">section 10</a> </p></td>
            <td valign="top"><p align="justify" 1"="">Registered persons not eligible under   the composition levy under sub-sections (1) and (2), but eligible to opt   to pay tax under sub-section (2A), of <a href="AC136.htm" class="testClick" 14"="">section 10</a> </p></td>
            <td valign="top"><p align="justify" 1"="">three per cent. of the <strong><span 12="" style13="" style10"=""><strong><sup>2</sup></strong></span>[</strong>turnover of] supplies of goods and services in the State or Union territory.]</p></td>
          </tr>
        </tbody>
      </table>
      </div></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><div align="justify" 1"="">
      <table width="700" border="0" cellspacing="0" cellpadding="0">
        <tbody><tr>
          <td width="31" valign="top"><span 9="" style13"=""><em><strong>1.</strong></em></span></td>
          <td width="669" valign="top"><div align="justify" 13"=""><em><strong><span 9"="">Subs. by CGST (Seventh Amendment) Rules, 2020 <a href="NC904.htm" class="testClick" 8="" style12"="">(S.No.566)</a> dated 24.06.2020 w.e.f. 01.04.2020 for "</span></strong></em>
            <table width="660" border="1" cellspacing="0" cellpadding="0">
              <tbody><tr>
                <td width="41" valign="top"><div align="center" 1="" style13"=""><em><strong>Sl.No.</strong></em></div></td>
                <td width="346" valign="top"><div align="center" 1="" style13"=""><em><strong>Category of registered persons</strong></em></div></td>
                <td width="305" valign="top"><div align="center" 1="" style13"=""><em><strong>Rate of tax</strong></em></div></td>
              </tr>
              <tr>
                <td valign="top"><div align="center" 15"="">(1)</div></td>
                <td valign="top"><div align="center" 1="" style13"=""><em><strong>(2)</strong></em></div></td>
                <td valign="top"><div align="center" 1="" style13"=""><em><strong>(3)</strong></em></div></td>
              </tr>
              <tr>
                <td valign="top"><div align="center" 1="" style13"=""><em><strong>1.</strong></em></div></td>
                <td valign="top"><div align="justify" 1="" style13"=""><em><strong>Manufacturers, other than manufacturers of such goods as may be notified by the Government</strong></em></div></td>
                <td valign="top"><div align="justify" 1="" style13"=""><em><strong><span 12="" style10"=""><sup>1A</sup></span>[half per cent. of the turnover   in the State or Union territory]</strong></em></div></td>
              </tr>
              <tr>
                <td valign="top"><div align="center" 1="" style13"=""><em><strong>2.</strong></em></div></td>
                <td valign="top"><div align="justify" 1="" style13"=""><em><strong>Suppliers making supplies referred to in clause (b) of paragraph 6 of <a href="AC309.htm" class="testClick" 12"="">Schedule II</a></strong></em></div></td>
                <td valign="top"><div align="justify" 1="" style13"=""><em><strong><span 12="" style10"=""><sup>2A</sup></span>[two and a half per   cent. of the turnover in the State or Union territory]</strong></em></div></td>
              </tr>
              <tr>
                <td valign="top"><div align="center" 1="" style13"=""><em><strong>3.</strong></em></div></td>
                <td valign="top"><div align="justify" 1="" style13"=""><em><strong>Any other supplier eligible for composition levy under <a href="AC136.htm" class="testClick" 12"="">section 10</a> and the provisions of this Chapter</strong></em></div></td>
                <td valign="top"><div align="justify" 1="" style13"=""><em><strong><span 12="" style10"=""><sup>3A</sup></span>[half per cent. of the   turnover of taxable supplies of <span 12="" style10"=""><sup>4A</sup></span>[goods and services] in the State or Union territory]</strong></em>"</div></td>
              </tr>
            </tbody></table>
            <table width="660" border="0" cellpadding="0" cellspacing="0">
              <tbody><tr>
                <td width="32" valign="top"><span 9="" style19"=""><em><strong>1A.</strong></em></span></td>
                <td width="628" valign="top"><div align="justify" 19"=""><em><strong><span 9"="">Subs. by CGST (Amendment) Rules, 2018 <a href="NC277.htm" class="testClick" 8="" style12"="">(S.No.164)</a> dated 23.01.2018 w.e.f. 01.01.2018 for "one per cent."</span></strong></em></div></td>
              </tr>
              <tr>
                <td valign="top"><span 9="" style19"=""><em><strong>2A.</strong></em></span></td>
                <td valign="top"><div align="justify" 19"=""><em><strong><span 9"="">Subs. by CGST (Amendment) Rules, 2018 <a href="NC277.htm" class="testClick" 8="" style12"="">(S.No.164)</a> dated 23.01.2018 w.e.f. 01.01.2018 for "two and a half per cent."</span></strong></em></div></td>
              </tr>
              <tr>
                <td valign="top"><span 9="" style19"=""><em><strong>3A.</strong></em></span></td>
                <td valign="top"><div align="justify" 19"=""><em><strong><span 9"="">Subs. by CGST (Amendment) Rules, 2018 <a href="NC277.htm" class="testClick" 8="" style12"="">(S.No.164)</a> dated 23.01.2018 w.e.f. 01.01.2018 for "half per cent."</span></strong></em></div></td>
              </tr>
              <tr>
                <td valign="top"><span 9="" style19"=""><em><strong>4A.</strong></em></span></td>
                <td valign="top"><div align="justify" 19"=""><em><strong><span 9"="">Subs. by CGST (Amendment) Rules, 2019 <a href="NC637.htm" class="testClick" 8="" style12"="">(S.No.337)</a> dated 29.01.2019 w.e.f. 01.02.2019 for "goods" </span></strong></em></div></td>
              </tr>
            </tbody></table>
            </div></td>
        </tr>
        <tr>
          <td valign="top"><span 15"="">2.</span></td>
          <td valign="top"><em><strong><span 9="" style13"="">Subs. by <a href="BO477.htm" class="testClick" 12"="">Corrigendum</a> Dated 25.06.2020 for "turnover of taxable" </span></strong></em></td>
        </tr>
      </tbody></table>
      </div></td>
  </tr>
</tbody></table>
<p align="center" 1"=""><strong><u>COMMENTARY</u></strong></p>
<table width="700" border="0" align="center" cellpadding="0" cellspacing="0">
  <tbody><tr>
    <td><p align="justify" 1"=""><strong>Rate of tax of the composition levy [Rule 7]</strong></p>
        <p align="justify" 1"=""> The category of registered persons, eligible for composition levy under <a href="AC136.htm" class="testClick" 14"="">section 10</a>  and the provisions of this Chapter, specified in column (2) of the Table below shall pay tax under section 10 at the rate specified in column (3) of the said Table:-</p>
        <table width="700" border="1" cellspacing="0" cellpadding="0">
          <tbody><tr>
            <td width="51" valign="top"><div align="center" 1"=""><strong>Sl.No.</strong></div></td>
            <td width="336" valign="top"><div align="center" 1"=""><strong>Category of registered persons</strong></div></td>
            <td width="305" valign="top"><div align="center" 1"=""><strong>Rate of tax</strong></div></td>
          </tr>
          <tr>
            <td valign="top"><div align="center" 1"=""><strong>(1)</strong></div></td>
            <td valign="top"><div align="center" 1"=""><strong>(2)</strong></div></td>
            <td valign="top"><div align="center" 1"=""><strong>(3)</strong></div></td>
          </tr>
          <tr>
            <td valign="top"><div align="center" 1"="">1.</div></td>
            <td valign="top"><div align="justify" 1"="">Manufacturers, other than manufacturers of such goods as may be notified by the Government</div></td>
            <td valign="top"><div align="justify" 1"="">Half per cent. of the turnover   in the State or Union territory</div></td>
          </tr>
          <tr>
            <td valign="top"><div align="center" 1"="">2.</div></td>
            <td valign="top"><div align="justify" 1"="">Suppliers making supplies referred to in clause (b) of paragraph 6 of <a href="AC309.htm" class="testClick" 14"="">Schedule II</a></div></td>
            <td valign="top"><div align="justify" 1"="">Two and a half per   cent. of the turnover in the State or Union territory</div></td>
          </tr>
          <tr>
            <td valign="top"><div align="center" 1"="">3.</div></td>
            <td valign="top"><div align="justify" 1"="">Any other supplier eligible for composition levy under <a href="AC136.htm" class="testClick" 14"="">section 10</a> and the provisions of this Chapter</div></td>
            <td valign="top"><div align="justify" 1"="">Half per cent. of the   turnover of taxable supplies of goods and services in the State or Union territory</div></td>
          </tr>
        </tbody></table>
        <p align="justify" 1"="">As per <a href="NC17.htm" class="testClick" 14"="">Notification No.08/2017-CT dated 27.06.2017</a> composition tax in case of other suppliers is payable only on taxable supply and no composition tax is to be paid on exempted supplies. Whereas in case of manufacturers and restaurant services composition tax is payable on total turnover including exempted turnover.</p>
    </td>
  </tr>
</tbody></table>
	</div>
</body>
</html>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
	$('body').on('click','.search',function(){
		var str = $('.search_val').val();
		console.log($('.html_block').text());
		str.search(search_word);
	})


</script>