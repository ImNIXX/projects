<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<!-- <form action="home/generateStrongPassword" method="POST"> -->
		<select class="form-control" name="length"><option value="4">4</option> <option value="6">6</option> <option value="7">7</option> <option value="8">8</option> <option value="9">9</option> <option value="10">10</option> <option value="12">12</option> <option value="15">15</option> <option value="18">18</option> <option value="20">20</option> <option value="25">25</option> <option value="28">28</option> <option value="30">30</option> <option value="36">36</option> <option value="40">40</option> <option value="50">50</option></select>
		<br>
		<input type="checkbox" name="lower">Lower
		<br>
		<input type="checkbox" name="upper">Upper
		<br>
		<input type="checkbox" name="number">Number
		<br>
		<input type="checkbox" name="special">Special
		<br>
		<!-- <input type="submit" name="sub"> -->
		<button class="submit">Generate</button>
	<!-- </form> -->
	<br><br>
	<input type="text" name="output">
</body>
</html>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
	
	var sChar = 'abcdefghijklmnopqrstuvwxyz';
	var cChar = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
	var num = '0123456789';
	var sym = '!@#$%^&*=-_';

	$('body').on('click','.submit',function(){
		var characters = sChar;
		var lower = $('input[name="lower"]').is(':checked');
		var upper = $('input[name="upper"]').is(':checked');
		var number = $('input[name="number"]').is(':checked');
		var special = $('input[name="special"]').is(':checked');
		var length = $('select[name="length"]').val();
		(upper ? characters += cChar : '');
		(number ? characters += num : '');
		(special ? characters += sym : '');
		password(length, characters);
	})

	function password(length, characters){
		var pwd = '';
		for (var i = 0; i < length; i++) {
			pwd += characters.charAt(Math.floor(Math.random() = characters.length));
		}
		alert(pwd);
	}

</script>