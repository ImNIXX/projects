<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	public function index()
	{
		$this->load->view('pass_generate/index.php');
	}

	public function search_web()
	{
		$this->load->view('search_web/index.php');
	}

	public function random_pass()
	{
		print_r($_POST);
		$length = $_POST['length'];
		$password = chr(mt_rand(97, 122));
		$add_dashes = false;
		$sets = array();
		$available_sets = 'luds';
	if(strpos($available_sets, 'l') !== false)
		$sets[] = 'abcdefghjkmnpqrstuvwxyz';
	if(strpos($available_sets, 'u') !== false)
		$sets[] = 'ABCDEFGHJKMNPQRSTUVWXYZ';
	if(strpos($available_sets, 'd') !== false)
		$sets[] = '23456789';
	if(strpos($available_sets, 's') !== false)
		$sets[] = '!@#$%&*?';

	$all = '';
	$password = '';
	foreach($sets as $set)
	{
		$password .= $set[array_rand(str_split($set))];
		$all .= $set;
	}

	$all = str_split($all);
	for($i = 0; $i < $length - count($sets); $i++)
		$password .= $all[array_rand($all)];

	$password = str_shuffle($password);

	if(!$add_dashes)
		return $password;

	$dash_len = floor(sqrt($length));
	$dash_str = '';
	while(strlen($password) > $dash_len)
	{
		$dash_str .= substr($password, 0, $dash_len) . '-';
		$password = substr($password, $dash_len);
	}
	$dash_str .= $password;
	print_r($dash_str);
	}
	function generateStrongPassword()
	{
		if(isset($_POST['lower'])){
			$a[] = 'l';
		}
		if(isset($_POST['upper'])){
			$a[] = 'u';
		}
		if(isset($_POST['number'])){
			$a[] = 'n';
		}
		if(isset($_POST['special'])){
			$a[] = 's';
		}
		$av_set = implode('', $a);
		$length = $_POST['length'];
		$sets = array();
		if(strpos($av_set, 'l') !== false)
			$sets[] = 'abcdefghjkmnpqrstuvwxyz';
		if(strpos($av_set, 'u') !== false)
			$sets[] = 'ABCDEFGHJKMNPQRSTUVWXYZ';
		if(strpos($av_set, 'n') !== false)
			$sets[] = '0123456789';
		if(strpos($av_set, 's') !== false)
			$sets[] = '!@#$%&*?';

		$all = '';
		$password = '';
		// print_r($sets);
		// print_r($sets[0][array_rand($sets, 1)]);
		foreach($sets as $set)
		{
			$password .= $set[array_rand(str_split($set))];
			$all .= $set;
		}

		$all = str_split($all);
		// print_r($all); die();
		for($i = 0; $i < $length - count($sets); $i++)
			$password .= $all[array_rand($all)];
			// print_r($password);
			// die();
		$password = str_shuffle($password);

		print_r($password);
		echo '<br>';
		print_r(md5($password));
	}
	
	public function file_base()
	{
		$abc['aaa'] = 'asd';
		$this->load->view('base_file/index.php', $abc);
	}


	public function file_to_base64($value='')
	{
		// print_r($_FILES); die();
		move_uploaded_file($_FILES['file']['tmp_name'], 'asstes/uploads/'.$_FILES['file']['name']);
		$aa = file_get_contents('asstes/uploads/'.$_FILES['file']['name']);
		$abc = base64_encode($aa);
		print_r($abc);
	}

	public function file_zip($value='')
	{
		# code...
	}
}
